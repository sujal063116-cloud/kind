import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Droplets, ShieldCheck, Heart, ArrowRight } from 'lucide-react';
import { AnimatedButton } from './AnimatedButton';

interface AtelierManifestoProps {
  onOpenConcierge: () => void;
  onOpenSoundStudio: () => void;
}

export const AtelierManifesto: React.FC<AtelierManifestoProps> = ({
  onOpenConcierge,
  onOpenSoundStudio,
}) => {
  const pillars = [
    {
      title: 'Haute Parfumerie in Grasse',
      subtitle: 'True Fine Fragrance',
      desc: 'Formulated in France’s historic perfume capital using cold-pressed essential oils. Zero artificial musks, phthalates, or caustic chemical aromas.',
      icon: <Sparkles className="w-4 h-4 text-[#B9975B]" />,
    },
    {
      title: 'Bio-Ferment Enzymatic Matrix',
      subtitle: 'Molecular Efficacy',
      desc: 'Sugar-derived proteases and lipases dissolve organic fats, protein fond, and watermarks in seconds without damaging honed marble or patina.',
      icon: <Droplets className="w-4 h-4 text-[#B9975B]" />,
    },
    {
      title: 'Heirloom Brass & Amber Glass',
      subtitle: 'Vessels Built for Generations',
      desc: 'Pharmaceutical-grade heavy amber glass protects botanical terpenes from UV light, paired with forged solid brass pumps engineered for life.',
      icon: <ShieldCheck className="w-4 h-4 text-[#B9975B]" />,
    },
    {
      title: 'Aquatic Ecosystem Safety',
      subtitle: '100% Readily Biodegradable',
      desc: 'Every drop breaks down harmlessly in greywater systems and natural waterways within 28 days. Safe for babies, pets, and precious heritage surfaces.',
      icon: <Heart className="w-4 h-4 text-[#B9975B]" />,
    },
  ];

  return (
    <section className="py-16 lg:py-24 bg-[#F2F1EE] relative overflow-hidden border-b border-[#EAE8E4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-3">
          <span className="text-[10px] uppercase font-mono tracking-[0.4em] text-[#B9975B] block font-bold">
            L&apos;Atelier Philosophie
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-light text-[#1C1C1C]">
            The Art of Domestic Restoration
          </h2>
          <p className="text-sm text-[#555555] font-light max-w-2xl mx-auto leading-relaxed font-sans">
            We believe the acts of caring for one&apos;s home should be an intimate luxury — a grounding sensory ritual that nourishes both your sanctuary and the senses.
          </p>
        </div>

        {/* Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {pillars.map((p, i) => (
            <motion.div
              key={i}
              whileHover={{ y: -4 }}
              transition={{ duration: 0.3 }}
              className="p-6 bg-[#FFFFFF] border border-[#EAE8E4] hover:border-[#B9975B] shadow-sm flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                <div className="w-8 h-8 bg-[#F8F7F4] border border-[#EAE8E4] flex items-center justify-center">
                  {p.icon}
                </div>
                <div>
                  <span className="text-[9px] uppercase font-mono tracking-[0.2em] text-[#B9975B] block font-bold">
                    {p.subtitle}
                  </span>
                  <h3 className="text-sm font-serif font-semibold text-[#1C1C1C] mt-0.5">{p.title}</h3>
                </div>
                <p className="text-[11px] text-[#555555] leading-relaxed">{p.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Interactive Consultation Banner */}
        <div className="mt-16 p-8 bg-[#FFFFFF] border border-[#EAE8E4] shadow-[0_20px_50px_rgba(0,0,0,0.04)] flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h3 className="text-xl sm:text-2xl font-serif font-light text-[#1C1C1C]">
              Discover Your Architectural Scent Prescription
            </h3>
            <p className="text-xs text-[#555555] font-sans">
              Take our interactive diagnostic consultation to match your marble, wood, and linens with bespoke elixirs.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3">
            <AnimatedButton
              id="btn-manifesto-open-sound"
              variant="secondary-glass"
              size="md"
              soundType="modal"
              onClick={onOpenSoundStudio}
              className="text-[10px] tracking-[0.2em]"
            >
              Sensory Audio Lab
            </AnimatedButton>

            <AnimatedButton
              id="btn-manifesto-open-concierge"
              variant="primary-solid-gold"
              size="md"
              soundType="droplet"
              onClick={onOpenConcierge}
              icon={<ArrowRight className="w-3.5 h-3.5" />}
              iconPosition="right"
              className="text-[10px] px-6 font-medium tracking-[0.25em]"
            >
              Begin Diagnostic
            </AnimatedButton>
          </div>
        </div>

      </div>
    </section>
  );
};
