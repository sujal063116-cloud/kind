import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Compass, Wind } from 'lucide-react';
import { sound } from '../utils/audio';

interface FragranceShowcaseProps {
  activeScent: string;
  onSelectScent: (scent: string) => void;
}

export const FragranceShowcase: React.FC<FragranceShowcaseProps> = ({
  activeScent,
  onSelectScent,
}) => {
  const scentFamilies = [
    {
      id: 'all',
      name: 'All Scent Families',
      subtitle: 'Complete Grasse Library',
      notes: 'Neroli · Santal · Fig · Cedar',
      color: 'from-amber-700/20 to-yellow-900/10',
      border: 'border-[#d4af37]/30',
    },
    {
      id: 'Citrus & Neroli',
      name: 'Citrus & Neroli',
      subtitle: 'Effervescent & Sunlit',
      notes: 'Calabrian Bergamot · Bitter Orange · Neroli Petals',
      color: 'from-amber-600/20 to-orange-900/10',
      border: 'border-amber-500/40',
    },
    {
      id: 'Smoked Santal',
      name: 'Smoked Santal',
      subtitle: 'Meditative & Grounding',
      notes: 'Mysore Sandalwood · Orris Root · Cardamom Pods',
      color: 'from-yellow-700/20 to-stone-900/10',
      border: 'border-yellow-600/40',
    },
    {
      id: 'Botanical Fig',
      name: 'Botanical Fig',
      subtitle: 'Herbaceous & Crisp',
      notes: 'Wild Fig Leaves · Cyclamen · Blonde Woods',
      color: 'from-emerald-700/20 to-teal-900/10',
      border: 'border-emerald-600/40',
    },
    {
      id: 'Wild Cedar & Vetiver',
      name: 'Wild Cedar & Vetiver',
      subtitle: 'Atmospheric & Deep',
      notes: 'Silver Fir · Atlas Cedarwood · Haitian Vetiver',
      color: 'from-teal-800/20 to-slate-900/10',
      border: 'border-teal-600/40',
    },
  ];

  return (
    <section className="py-12 bg-[#F2F1EE] border-b border-[#EAE8E4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#FFFFFF] border border-[#EAE8E4] text-[#B9975B] text-[10px] font-mono tracking-[0.3em] uppercase mb-2">
              <Compass className="w-3.5 h-3.5 text-[#B9975B]" />
              The Grasse Olfactory Accord
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-light text-[#1C1C1C]">
              Curate by Sensory Mood
            </h2>
          </div>
          <p className="text-xs text-[#555555] max-w-md font-sans">
            Our master perfumers in Grasse formulate each functional elixir as a true fine fragrance, replacing the pungent chemical fumes of legacy cleaners with sublime aromatherapy.
          </p>
        </div>

        {/* Grid of Scent Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {scentFamilies.map(family => {
            const isSelected = activeScent === family.id;
            return (
              <motion.div
                key={family.id}
                id={`card-scent-${family.id.replace(/\s+/g, '-').toLowerCase()}`}
                whileHover={{ y: -3 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => {
                  sound.playDroplet();
                  onSelectScent(family.id);
                }}
                className={`
                  p-4 border transition-all duration-300 cursor-pointer select-none bg-[#FFFFFF]
                  ${
                    isSelected
                      ? 'border-[#B9975B] shadow-[0_8px_25px_rgba(185,151,91,0.18)] ring-1 ring-[#B9975B]'
                      : 'border-[#EAE8E4] hover:border-[#B9975B]/60 shadow-sm'
                  }
                `}
              >
                <div className="flex items-center justify-between mb-2">
                  <Wind className={`w-3.5 h-3.5 ${isSelected ? 'text-[#B9975B]' : 'text-[#777777]'}`} />
                  {isSelected && (
                    <span className="w-1.5 h-1.5 bg-[#B9975B]" />
                  )}
                </div>

                <h4 className="text-xs font-serif font-medium text-[#1C1C1C] mb-0.5">{family.name}</h4>
                <p className="text-[10px] text-[#B9975B] font-mono tracking-wider mb-2">{family.subtitle}</p>
                <p className="text-[10px] text-[#777777] italic line-clamp-2">{family.notes}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
