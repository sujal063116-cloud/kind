import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, ArrowRight, ShieldCheck, Droplets, Compass, Check, Plus } from 'lucide-react';
import { AnimatedButton } from './AnimatedButton';
import { Product } from '../types';
import { sound } from '../utils/audio';

interface HeroSectionProps {
  signatureProduct: Product;
  onAddToCart: (product: Product, isRefill?: boolean) => void;
  onOpenProductDetail: (product: Product) => void;
  onOpenConcierge: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  signatureProduct,
  onAddToCart,
  onOpenProductDetail,
  onOpenConcierge,
}) => {
  const [activeHotspot, setActiveHotspot] = useState<number | null>(null);
  const [activeNoteTab, setActiveNoteTab] = useState<'top' | 'heart' | 'base'>('top');
  const [isAdded, setIsAdded] = useState(false);

  const hotspots = [
    {
      id: 1,
      x: '52%',
      y: '18%',
      title: 'Forged Champagne Brass Pump',
      desc: 'Precision micro-aerosol delivery mechanism engineered to mist 0.12ml without dripping.',
    },
    {
      id: 2,
      x: '48%',
      y: '42%',
      title: 'Active Quadruple Bio-Enzyme Matrix',
      desc: 'Plant-derived lipases and proteases that naturally dissolve grease at the molecular level.',
    },
    {
      id: 3,
      x: '64%',
      y: '65%',
      title: 'Apothecary Amber UV-Shield Glass',
      desc: 'Heirloom 500ml pharmaceutical vessel protecting active botanical terpenes from photo-oxidation.',
    },
    {
      id: 4,
      x: '36%',
      y: '80%',
      title: 'Cold-Pressed Neroli & Bergamot',
      desc: 'Distilled in Grasse, France with zero synthetic fragrances or endocrine disruptors.',
    },
  ];

  const handleHotspotClick = (id: number) => {
    sound.playDroplet();
    setActiveHotspot(activeHotspot === id ? null : id);
  };

  const handleQuickAdd = () => {
    onAddToCart(signatureProduct, false);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <section className="relative overflow-hidden bg-[#F8F7F4] py-12 lg:py-24 border-b border-[#EAE8E4]">
      {/* Decorative Architectural Grid Lines */}
      <div className="absolute top-0 left-[8%] w-[1px] h-full bg-[#EAE8E4] pointer-events-none hidden md:block" />
      <div className="absolute top-0 left-[50%] w-[1px] h-full bg-[#EAE8E4] pointer-events-none hidden lg:block" />
      <div className="absolute top-[80px] left-0 w-full h-[1px] bg-[#EAE8E4] pointer-events-none" />

      {/* Large Background Typography Watermark */}
      <div className="absolute -right-8 top-1/2 -translate-y-1/2 rotate-90 origin-center pointer-events-none select-none hidden xl:block z-0">
        <span className="text-[140px] font-serif font-bold text-[#EAE8E4]/70 leading-none tracking-tighter">
          ELIXIR
        </span>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Haute Editorial Copy */}
          <div className="lg:col-span-6 space-y-6">
            {/* Tagline / Accord */}
            <div className="flex items-center gap-3">
              <div className="h-[1px] w-10 bg-[#B9975B]" />
              <span className="text-[9px] tracking-[0.5em] text-[#B9975B] uppercase font-mono font-bold">
                The Spring Synthesis · No. 01
              </span>
            </div>

            {/* Main Headline */}
            <div className="space-y-3">
              <h1 className="text-5xl sm:text-6xl lg:text-[84px] font-serif font-light text-[#1C1C1C] leading-[0.88] tracking-tight -ml-1">
                Pure <br />
                <span className="italic text-[#B9975B] ml-8 sm:ml-16">Sanctuary.</span>
              </h1>
              <p className="text-sm font-light text-[#555555] leading-relaxed max-w-md pt-2">
                Redefining domestic elegance through molecular alchemy. Our limited-release botanical concentrates transform the act of cleaning into a curated sensory experience.
              </p>
            </div>

            {/* Olfactory Scent Pyramid Explorer Tabs */}
            <div className="p-4 sm:p-5 bg-[#FFFFFF] border border-[#EAE8E4] shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-widest text-[#777777] font-mono flex items-center gap-1.5">
                  <Compass className="w-3.5 h-3.5 text-[#B9975B]" />
                  Fragrance Accord: Citrus & Neroli
                </span>
                <span className="text-[10px] text-[#B9975B] font-mono uppercase tracking-wider">Grasse Extraction No. 04</span>
              </div>

              {/* Tabs */}
              <div className="grid grid-cols-3 gap-2">
                {(['top', 'heart', 'base'] as const).map(tab => (
                  <button
                    key={tab}
                    id={`btn-scent-tab-${tab}`}
                    onClick={() => {
                      sound.playSubtleClick();
                      setActiveNoteTab(tab);
                    }}
                    className={`py-1 px-2 text-[10px] font-medium uppercase tracking-[0.2em] transition-all duration-300 cursor-pointer ${
                      activeNoteTab === tab
                        ? 'bg-[#1C1C1C] text-white'
                        : 'bg-[#F2F1EE] text-[#555555] hover:text-[#1C1C1C]'
                    }`}
                  >
                    {tab === 'top' ? 'Top Notes' : tab === 'heart' ? 'Heart Notes' : 'Base Notes'}
                  </button>
                ))}
              </div>

              {/* Tab Notes Content */}
              <div className="pt-1 text-xs">
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeNoteTab}
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    className="flex flex-wrap gap-2"
                  >
                    {signatureProduct.notes[activeNoteTab].map((note, i) => (
                      <span
                        key={i}
                        className="px-2.5 py-0.5 bg-[#F8F7F4] border border-[#EAE8E4] text-[#1C1C1C] text-xs font-serif italic"
                      >
                        {note}
                      </span>
                    ))}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>

            {/* Dynamic Animated Call to Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3.5 pt-2">
              <AnimatedButton
                id="btn-hero-add-signature"
                variant="primary-solid-gold"
                size="lg"
                soundType="cart"
                onClick={handleQuickAdd}
                className="flex-1 text-[11px] tracking-[0.3em] font-medium shadow-sm"
                icon={isAdded ? <Check className="w-4 h-4 text-white" /> : <ArrowRight className="w-4 h-4" />}
                iconPosition="right"
              >
                {isAdded ? 'Added to Bag' : `Acquire the Collection · $${signatureProduct.price}`}
              </AnimatedButton>

              <AnimatedButton
                id="btn-hero-open-concierge"
                variant="secondary-glass"
                size="lg"
                soundType="droplet"
                onClick={onOpenConcierge}
                className="text-[11px] tracking-[0.25em]"
                icon={<Sparkles className="w-3.5 h-3.5 text-[#B9975B]" />}
              >
                Diagnostic Matcher
              </AnimatedButton>
            </div>

            {/* Guarantees & Credentials */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-[#EAE8E4] text-[10px] text-[#777777]">
              <div className="flex items-center gap-1.5">
                <Droplets className="w-3.5 h-3.5 text-[#B9975B] shrink-0" />
                <span className="font-mono uppercase tracking-wider">100% Biodegradable</span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#B9975B] shrink-0" />
                <span className="font-mono uppercase tracking-wider">Marble Safe</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#B9975B] shrink-0" />
                <span className="font-mono uppercase tracking-wider">Heirloom Glass</span>
              </div>
            </div>
          </div>

          {/* Right Column: Floating Product Visual Card with Hotspots */}
          <div className="lg:col-span-6 relative flex items-center justify-center lg:justify-end">
            
            {/* Main Interactive Stage */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="relative w-full max-w-[480px] bg-[#FFFFFF] shadow-[0_40px_80px_-15px_rgba(0,0,0,0.08)] border border-[#EAE8E4] p-1.5 transform lg:rotate-1 hover:rotate-0 transition-transform duration-500 flex flex-col"
            >
              {/* Inner Presentation Box */}
              <div className="relative bg-[#F2F1EE] border border-[#EAE8E4] h-[400px] flex items-center justify-center p-6 select-none overflow-hidden">
                {/* Botanical Architectural Lines */}
                <div className="absolute top-8 left-8 w-16 h-[1px] bg-[#1C1C1C]" />
                <div className="absolute bottom-8 right-8 text-right">
                  <span className="block text-[8px] tracking-[0.4em] uppercase font-mono text-[#B9975B] mb-0.5">
                    Formula Integrity
                  </span>
                  <span className="block text-xs font-serif italic text-[#1C1C1C]">
                    99.4% Botanical
                  </span>
                </div>

                {/* Central Bottle Image */}
                <motion.img
                  src={signatureProduct.image}
                  alt={signatureProduct.name}
                  whileHover={{ scale: 1.03 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                  className="max-h-[300px] object-contain drop-shadow-[0_20px_35px_rgba(0,0,0,0.12)] select-none cursor-pointer"
                  onClick={() => onOpenProductDetail(signatureProduct)}
                />

                {/* Interactive Hotspot Pins */}
                {hotspots.map(spot => {
                  const isActive = activeHotspot === spot.id;
                  return (
                    <div
                      key={spot.id}
                      style={{ left: spot.x, top: spot.y }}
                      className="absolute -translate-x-1/2 -translate-y-1/2 z-30"
                    >
                      <button
                        id={`btn-hotspot-${spot.id}`}
                        onClick={() => handleHotspotClick(spot.id)}
                        className={`
                          w-6 h-6 flex items-center justify-center transition-all duration-300 focus:outline-none cursor-pointer
                          ${
                            isActive
                              ? 'bg-[#1C1C1C] text-white border border-[#B9975B] shadow-md'
                              : 'bg-[#FFFFFF] text-[#1C1C1C] border border-[#EAE8E4] shadow-sm hover:border-[#B9975B]'
                          }
                        `}
                      >
                        <Plus className={`w-3 h-3 transition-transform ${isActive ? 'rotate-45 text-[#B9975B]' : ''}`} />
                      </button>

                      {/* Hotspot Floating Tooltip Popover */}
                      <AnimatePresence>
                        {isActive && (
                          <motion.div
                            initial={{ opacity: 0, scale: 0.9, y: 6 }}
                            animate={{ opacity: 1, scale: 1, y: 0 }}
                            exit={{ opacity: 0, scale: 0.9, y: 4 }}
                            className="absolute left-8 -top-3 w-56 p-3 bg-[#FFFFFF] border border-[#EAE8E4] shadow-[0_15px_35px_rgba(0,0,0,0.1)] z-40 text-left pointer-events-auto"
                          >
                            <h5 className="text-xs font-serif font-semibold text-[#1C1C1C] mb-1">
                              {spot.title}
                            </h5>
                            <p className="text-[10px] text-[#555555] leading-relaxed">{spot.desc}</p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>

              {/* Bottom Card Summary Bar */}
              <div className="bg-[#FFFFFF] p-4 flex items-center justify-between border-t border-[#EAE8E4]">
                <div>
                  <h3 className="text-xs font-medium uppercase tracking-[0.2em] text-[#1C1C1C]">
                    {signatureProduct.frenchTitle}
                  </h3>
                  <p className="text-[10px] text-[#888888] font-mono tracking-wider">
                    {signatureProduct.scentProfile} · 500ml
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-xl font-serif font-light text-[#1C1C1C]">
                    ${signatureProduct.price}
                  </span>
                  <AnimatedButton
                    id="btn-hero-quick-view-dossier"
                    variant="outline-minimal"
                    size="sm"
                    soundType="click"
                    onClick={() => onOpenProductDetail(signatureProduct)}
                    className="text-[10px] py-1.5 px-3"
                  >
                    Dossier
                  </AnimatedButton>
                </div>
              </div>
            </motion.div>
          </div>

        </div>
      </div>
    </section>
  );
};
