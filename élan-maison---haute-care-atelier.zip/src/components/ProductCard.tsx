import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Star, Eye, ShoppingBag, Droplets, Sparkles, Check } from 'lucide-react';
import { Product } from '../types';
import { AnimatedButton } from './AnimatedButton';
import { sound } from '../utils/audio';

interface ProductCardProps {
  product: Product;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, isRefill?: boolean) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onSelectProduct,
  onAddToCart,
}) => {
  const [selectedFormat, setSelectedFormat] = useState<'vessel' | 'refill'>('vessel');
  const [isAdded, setIsAdded] = useState(false);

  const price = selectedFormat === 'vessel' ? product.price : product.refillPrice;

  const handleAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    onAddToCart(product, selectedFormat === 'refill');
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const handleQuickView = (e: React.MouseEvent) => {
    e.stopPropagation();
    onSelectProduct(product);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      whileHover={{ y: -6 }}
      transition={{ duration: 0.4 }}
      onClick={() => onSelectProduct(product)}
      className="group relative bg-[#FFFFFF] border border-[#EAE8E4] hover:border-[#B9975B] shadow-[0_10px_30px_rgba(0,0,0,0.04)] hover:shadow-[0_20px_45px_rgba(0,0,0,0.08)] overflow-hidden flex flex-col transition-all duration-300 cursor-pointer select-none"
    >
      {/* Top Image Container */}
      <div className="relative aspect-[4/4] overflow-hidden bg-[#F2F1EE] border-b border-[#EAE8E4] flex items-center justify-center p-4">
        {/* Product Image */}
        <motion.img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-contain filter drop-shadow-[0_10px_20px_rgba(0,0,0,0.08)] group-hover:scale-105 transition-transform duration-500"
          loading="lazy"
        />

        {/* Badge */}
        {product.badge && (
          <div className="absolute top-3 left-3 z-10">
            <span className="px-2.5 py-1 text-[9px] uppercase font-mono tracking-[0.2em] bg-[#1C1C1C] text-white">
              {product.badge}
            </span>
          </div>
        )}

        {/* Eco Metric Chip */}
        <div className="absolute top-3 right-3 z-10">
          <span className="px-2 py-0.5 text-[9px] font-mono bg-[#FFFFFF] border border-[#EAE8E4] text-[#1C1C1C] flex items-center gap-1">
            <Droplets className="w-2.5 h-2.5 text-[#B9975B]" />
            100% Bio
          </span>
        </div>

        {/* Quick View Hover Button */}
        <div className="absolute inset-x-4 bottom-4 z-20 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-y-2 group-hover:translate-y-0 flex justify-center">
          <AnimatedButton
            id={`btn-quick-view-${product.id}`}
            variant="secondary-glass"
            size="sm"
            soundType="modal"
            onClick={handleQuickView}
            icon={<Eye className="w-3 h-3 text-[#B9975B]" />}
            className="w-full text-[10px] tracking-[0.2em] shadow-sm bg-[#FFFFFF] border-[#B9975B]"
          >
            Formulation Specs
          </AnimatedButton>
        </div>
      </div>

      {/* Product Content Body */}
      <div className="p-5 flex-1 flex flex-col justify-between space-y-4">
        {/* Rating and Olfactory Category */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[10px] font-mono uppercase tracking-[0.2em] text-[#B9975B] flex items-center gap-1 font-semibold">
              <Sparkles className="w-3 h-3" />
              {product.fragranceFamily}
            </span>
            <div className="flex items-center gap-1 text-[#777777]">
              <Star className="w-3 h-3 fill-[#B9975B] text-[#B9975B]" />
              <span className="text-xs font-mono text-[#1C1C1C]">{product.rating}</span>
              <span className="text-[10px] text-[#888888]">({product.reviewsCount})</span>
            </div>
          </div>

          <h3 className="font-serif text-base text-[#1C1C1C] group-hover:text-[#B9975B] transition-colors leading-snug font-medium">
            {product.name}
          </h3>
          <p className="text-xs text-[#777777] italic font-serif -mt-0.5 line-clamp-1">
            {product.frenchTitle}
          </p>
        </div>

        {/* Top Aroma Notes Pill Bar */}
        <div className="flex flex-wrap gap-1.5">
          {product.notes.top.slice(0, 3).map((note, i) => (
            <span
              key={i}
              className="text-[9px] px-2 py-0.5 bg-[#F8F7F4] border border-[#EAE8E4] text-[#555555] font-mono"
            >
              {note}
            </span>
          ))}
        </div>

        {/* Format Selector: Flacon vs Refill Pouch */}
        <div className="pt-2 border-t border-[#EAE8E4]">
          <div className="grid grid-cols-2 gap-1 p-0.5 bg-[#F8F7F4] border border-[#EAE8E4] text-[10px] uppercase font-mono tracking-wider">
            <button
              id={`btn-format-vessel-${product.id}`}
              onClick={e => {
                e.stopPropagation();
                sound.playSubtleClick();
                setSelectedFormat('vessel');
              }}
              className={`py-1 px-2 transition-all cursor-pointer ${
                selectedFormat === 'vessel'
                  ? 'bg-[#1C1C1C] text-white font-medium'
                  : 'text-[#777777] hover:text-[#1C1C1C]'
              }`}
            >
              Glass Vessel
            </button>
            <button
              id={`btn-format-refill-${product.id}`}
              onClick={e => {
                e.stopPropagation();
                sound.playSubtleClick();
                setSelectedFormat('refill');
              }}
              className={`py-1 px-2 transition-all cursor-pointer ${
                selectedFormat === 'refill'
                  ? 'bg-[#1C1C1C] text-white font-medium'
                  : 'text-[#777777] hover:text-[#1C1C1C]'
              }`}
            >
              Refill (-35%)
            </button>
          </div>
        </div>

        {/* Price & Add to Bag Dynamic Button */}
        <div className="pt-1 flex items-center justify-between gap-3">
          <div>
            <span className="text-lg font-serif font-light text-[#1C1C1C]">${price}</span>
            <span className="text-[9px] text-[#888888] block font-mono">
              {selectedFormat === 'vessel' ? product.volume : 'Refill Concentrate'}
            </span>
          </div>

          <AnimatedButton
            id={`btn-add-to-cart-${product.id}`}
            variant={selectedFormat === 'refill' ? 'primary-gold' : 'primary-solid-gold'}
            size="sm"
            soundType="cart"
            onClick={handleAdd}
            icon={isAdded ? <Check className="w-3.5 h-3.5 text-white" /> : <ShoppingBag className="w-3 h-3" />}
            className="flex-1 text-[10px] py-2 tracking-[0.2em]"
          >
            {isAdded ? 'Added' : 'Acquire'}
          </AnimatedButton>
        </div>
      </div>
    </motion.div>
  );
};
