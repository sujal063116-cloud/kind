import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { sound } from '../utils/audio';

interface AnimatedButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary-gold' | 'primary-solid-gold' | 'secondary-glass' | 'outline-minimal' | 'icon-round' | 'pill-scent';
  size?: 'sm' | 'md' | 'lg' | 'icon';
  soundType?: 'click' | 'cart' | 'droplet' | 'toggle' | 'modal' | 'none';
  icon?: React.ReactNode;
  iconPosition?: 'left' | 'right';
  className?: string;
  enableMagnetic?: boolean;
  badge?: string | number;
}

interface Particle {
  id: number;
  x: number;
  y: number;
  angle: number;
  speed: number;
  size: number;
  color: string;
}

export const AnimatedButton: React.FC<AnimatedButtonProps> = ({
  children,
  variant = 'primary-gold',
  size = 'md',
  soundType = 'click',
  icon,
  iconPosition = 'left',
  className = '',
  enableMagnetic = true,
  badge,
  onClick,
  onMouseEnter,
  disabled,
  ...rest
}) => {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [ripples, setRipples] = useState<{ id: number; x: number; y: number }[]>([]);
  const [magneticOffset, setMagneticOffset] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (!enableMagnetic || disabled || !buttonRef.current) return;
    const rect = buttonRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const distanceX = (e.clientX - centerX) * 0.22;
    const distanceY = (e.clientY - centerY) * 0.22;
    setMagneticOffset({ x: distanceX, y: distanceY });
  };

  const handleMouseLeave = () => {
    setIsHovered(false);
    setMagneticOffset({ x: 0, y: 0 });
  };

  const handleMouseEnter = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled) return;
    setIsHovered(true);
    sound.playHoverShimmer();
    if (onMouseEnter) onMouseEnter(e);
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (disabled) return;

    // Trigger designated sound
    switch (soundType) {
      case 'cart':
        sound.playAddCart();
        break;
      case 'droplet':
        sound.playDroplet();
        break;
      case 'toggle':
        sound.playMetallicToggle();
        break;
      case 'modal':
        sound.playModalOpen();
        break;
      case 'click':
        sound.playSubtleClick();
        break;
      case 'none':
        break;
      default:
        sound.playSubtleClick();
    }

    // Spawn burst particles and liquid ripple
    if (buttonRef.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;

      // Ripple
      const rippleId = Date.now();
      setRipples(prev => [...prev.slice(-3), { id: rippleId, x: clickX, y: clickY }]);
      setTimeout(() => {
        setRipples(prev => prev.filter(r => r.id !== rippleId));
      }, 700);

      // Particle sparks
      const newParticles: Particle[] = Array.from({ length: 8 }).map((_, i) => ({
        id: Date.now() + i,
        x: clickX,
        y: clickY,
        angle: (i * (360 / 8) + Math.random() * 20) * (Math.PI / 180),
        speed: 25 + Math.random() * 35,
        size: 3 + Math.random() * 3,
        color: ['#d4af37', '#f3e5ab', '#ffffff', '#c5a059'][Math.floor(Math.random() * 4)],
      }));

      setParticles(prev => [...prev.slice(-12), ...newParticles]);
      setTimeout(() => {
        setParticles(prev => prev.filter(p => !newParticles.some(np => np.id === p.id)));
      }, 600);
    }

    if (onClick) onClick(e);
  };

  // Base sizing
  const sizeClasses = {
    sm: 'px-3.5 py-1.5 text-xs tracking-wider gap-1.5 min-h-[34px]',
    md: 'px-5 py-2.5 text-[11px] tracking-[0.25em] gap-2 min-h-[44px]',
    lg: 'px-7 py-3.5 text-xs tracking-[0.3em] gap-3 min-h-[50px]',
    icon: 'p-2.5 min-w-[40px] min-h-[40px] justify-center items-center',
  }[size];

  // Variants styling for Artistic Flair
  const variantStyles = {
    'primary-gold': `
      bg-[#1C1C1C]
      text-[#FFFFFF]
      border border-[#B9975B]/60 hover:border-[#B9975B]
      shadow-[0_4px_20px_rgba(28,28,28,0.15)]
      hover:shadow-[0_8px_30px_rgba(185,151,91,0.25)]
    `,
    'primary-solid-gold': `
      bg-[#1C1C1C]
      text-[#FFFFFF] font-medium
      border border-[#B9975B]
      shadow-[0_6px_25px_rgba(28,28,28,0.2)]
      hover:bg-[#B9975B] hover:text-[#FFFFFF] hover:border-[#B9975B]
    `,
    'secondary-glass': `
      bg-[#FFFFFF]
      text-[#1C1C1C]
      border border-[#EAE8E4] hover:border-[#B9975B]/70
      shadow-[0_2px_12px_rgba(0,0,0,0.04)]
      hover:bg-[#F2F1EE]
    `,
    'outline-minimal': `
      bg-transparent
      text-[#1C1C1C] hover:text-[#B9975B]
      border border-[#D8D4CC] hover:border-[#B9975B]
      hover:bg-[#B9975B]/5
    `,
    'icon-round': `
      bg-[#FFFFFF]
      text-[#1C1C1C] hover:text-[#B9975B]
      border border-[#EAE8E4] hover:border-[#B9975B]
      rounded-full
      shadow-[0_2px_10px_rgba(0,0,0,0.05)]
    `,
    'pill-scent': `
      bg-[#FFFFFF]
      text-[#555555] hover:text-[#1C1C1C]
      border border-[#EAE8E4] hover:border-[#B9975B]
      rounded-full
    `,
  }[variant];

  return (
    <motion.button
      ref={buttonRef}
      disabled={disabled}
      animate={{
        x: magneticOffset.x,
        y: magneticOffset.y,
        scale: isHovered && !disabled ? 1.02 : 1,
      }}
      whileTap={{ scale: disabled ? 1 : 0.96 }}
      transition={{ type: 'spring', stiffness: 400, damping: 25 }}
      onMouseMove={handleMouseMove}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      onClick={handleClick}
      className={`
        relative overflow-hidden inline-flex items-center justify-center
        uppercase font-medium select-none cursor-pointer
        transition-all duration-300
        ${disabled ? 'opacity-40 cursor-not-allowed' : ''}
        ${variant === 'icon-round' || variant === 'pill-scent' ? '' : 'rounded-none'}
        ${sizeClasses}
        ${variantStyles}
        ${className}
      `}
      {...rest}
    >
      {/* Dynamic Animated Light Beam Sweep */}
      <motion.div
        className="absolute inset-0 pointer-events-none z-0"
        initial={{ x: '-100%' }}
        animate={{ x: isHovered ? '200%' : '-100%' }}
        transition={{ duration: 0.85, ease: 'easeInOut' }}
        style={{
          background: 'linear-gradient(90deg, transparent, rgba(185,151,91,0.25), transparent)',
        }}
      />

      {/* Outer Offset Artistic Frame Aura on Hover */}
      {isHovered && !disabled && (
        <motion.div
          className="absolute -inset-1 border border-[#B9975B] pointer-events-none z-0 opacity-40"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 0.8, scale: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
        />
      )}

      {/* Ripple Animation Effect on Click */}
      <AnimatePresence>
        {ripples.map(ripple => (
          <motion.span
            key={ripple.id}
            initial={{ scale: 0, opacity: 0.5 }}
            animate={{ scale: 3.5, opacity: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
            className="absolute rounded-full pointer-events-none z-10"
            style={{
              left: ripple.x - 20,
              top: ripple.y - 20,
              width: 40,
              height: 40,
              background: 'rgba(185, 151, 91, 0.35)',
            }}
          />
        ))}
      </AnimatePresence>

      {/* Particle Sparks Burst on Click */}
      <AnimatePresence>
        {particles.map(p => (
          <motion.span
            key={p.id}
            initial={{ x: p.x, y: p.y, scale: 1, opacity: 1 }}
            animate={{
              x: p.x + Math.cos(p.angle) * p.speed,
              y: p.y + Math.sin(p.angle) * p.speed,
              scale: 0.2,
              opacity: 0,
            }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: 'easeOut' }}
            className="absolute rounded-full pointer-events-none z-20"
            style={{
              width: p.size,
              height: p.size,
              backgroundColor: p.color,
              boxShadow: `0 0 6px ${p.color}`,
            }}
          />
        ))}
      </AnimatePresence>

      {/* Button Content */}
      <span className="relative z-10 flex items-center justify-center gap-2 whitespace-nowrap">
        {icon && iconPosition === 'left' && (
          <motion.span
            animate={{ rotate: isHovered ? [0, -6, 6, 0] : 0 }}
            transition={{ duration: 0.4 }}
            className="inline-flex shrink-0"
          >
            {icon}
          </motion.span>
        )}

        <span>{children}</span>

        {icon && iconPosition === 'right' && (
          <motion.span
            animate={{ x: isHovered ? 3 : 0 }}
            transition={{ type: 'spring', stiffness: 300, damping: 20 }}
            className="inline-flex shrink-0"
          >
            {icon}
          </motion.span>
        )}

        {badge !== undefined && (
          <span className="ml-1.5 px-1.5 py-0.5 text-[9px] font-bold rounded-none bg-[#B9975B] text-white shrink-0">
            {badge}
          </span>
        )}
      </span>
    </motion.button>
  );
};
