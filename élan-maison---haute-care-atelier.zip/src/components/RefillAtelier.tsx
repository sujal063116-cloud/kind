import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Sparkles, Droplets, ShieldCheck, Check, ShoppingBag, Leaf, Award } from 'lucide-react';
import { Product } from '../types';
import { AnimatedButton } from './AnimatedButton';
import { sound } from '../utils/audio';

interface RefillAtelierProps {
  products: Product[];
  onAddToCart: (product: Product, isRefill?: boolean) => void;
}

export const RefillAtelier: React.FC<RefillAtelierProps> = ({ products, onAddToCart }) => {
  // Select 3 refill concentrates
  const availableRefills = products.filter(p => p.category !== 'utensils' && p.category !== 'sets');
  const [selectedIds, setSelectedIds] = useState<string[]>([
    availableRefills[0]?.id || '',
    availableRefills[1]?.id || '',
    availableRefills[2]?.id || '',
  ]);
  const [cadence, setCadence] = useState<'60' | '90' | '120'>('90');
  const [isAdded, setIsAdded] = useState(false);

  const toggleSelect = (id: string) => {
    sound.playSubtleClick();
    if (selectedIds.includes(id)) {
      if (selectedIds.length > 1) {
        setSelectedIds(selectedIds.filter(i => i !== id));
      }
    } else {
      if (selectedIds.length < 3) {
        setSelectedIds([...selectedIds, id]);
      } else {
        // replace last
        setSelectedIds([...selectedIds.slice(1), id]);
      }
    }
  };

  const selectedProducts = availableRefills.filter(p => selectedIds.includes(p.id));
  const rawTotal = selectedProducts.reduce((sum, p) => sum + p.refillPrice, 0);
  const subscriptionDiscount = 0.85; // 15% off recurring
  const finalPrice = Math.round(rawTotal * subscriptionDiscount);
  const plasticEliminated = selectedProducts.reduce((sum, p) => sum + p.ecoMetrics.plasticSavedGrams, 0);

  const handleSubscribe = () => {
    selectedProducts.forEach(p => onAddToCart(p, true));
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  return (
    <section className="py-16 lg:py-24 bg-[#F8F7F4] border-t border-b border-[#EAE8E4] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-[#FFFFFF] border border-[#EAE8E4] text-[#B9975B] text-[10px] font-mono tracking-[0.3em] uppercase">
            <Leaf className="w-3.5 h-3.5 text-[#B9975B]" />
            Circular Luxury & Permanent Vessels
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-serif font-light text-[#1C1C1C]">
            The Infinite Botanical Decanter
          </h2>
          <p className="text-sm text-[#555555] font-light max-w-2xl mx-auto leading-relaxed font-sans">
            Acquire heirloom glass once. Refill endlessly with 100% recyclable aluminum concentrates formulated in Grasse. Enjoy 15% recurring privilege and free residence delivery.
          </p>
        </div>

        {/* Interactive Subscription Box Builder Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left: Product Concentrate Picker */}
          <div className="lg:col-span-7 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[10px] uppercase tracking-[0.2em] text-[#777777] font-mono">
                Select 3 Formulations ({selectedIds.length}/3 selected)
              </span>
              <span className="text-[10px] text-[#B9975B] font-mono uppercase tracking-wider">Tap to customize</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {availableRefills.map(p => {
                const isSelected = selectedIds.includes(p.id);
                return (
                  <motion.div
                    key={p.id}
                    id={`btn-refill-pick-${p.id}`}
                    whileHover={{ scale: 1.01 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => toggleSelect(p.id)}
                    className={`
                      p-4 border transition-all duration-300 cursor-pointer select-none relative flex flex-col justify-between bg-[#FFFFFF]
                      ${
                        isSelected
                          ? 'border-[#B9975B] shadow-[0_4px_20px_rgba(185,151,91,0.15)] ring-1 ring-[#B9975B]'
                          : 'border-[#EAE8E4] hover:border-[#B9975B]/60 shadow-sm'
                      }
                    `}
                  >
                    {/* Active Checkmark Pill */}
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div>
                        <span className="text-[9px] text-[#B9975B] uppercase font-mono tracking-wider block">
                          {p.fragranceFamily}
                        </span>
                        <h4 className="text-xs font-serif font-medium text-[#1C1C1C]">{p.name}</h4>
                      </div>
                      <div
                        className={`w-4 h-4 flex items-center justify-center border transition-all ${
                          isSelected
                            ? 'bg-[#1C1C1C] border-[#1C1C1C] text-white'
                            : 'border-[#EAE8E4] text-transparent'
                        }`}
                      >
                        <Check className="w-3 h-3 stroke-[3]" />
                      </div>
                    </div>

                    <div className="pt-2 border-t border-[#EAE8E4] flex items-center justify-between text-xs">
                      <span className="text-[#777777] text-[10px]">500ml Refill Pouch</span>
                      <span className="font-serif text-[#1C1C1C] font-medium">${p.refillPrice}</span>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Right: Box Summary & Cadence Customizer Card */}
          <div className="lg:col-span-5">
            <div className="bg-[#FFFFFF] border border-[#EAE8E4] p-6 sm:p-7 shadow-[0_20px_50px_rgba(0,0,0,0.06)] space-y-6">
              <div className="flex items-center justify-between pb-3 border-b border-[#EAE8E4]">
                <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#B9975B] font-bold">
                  Bespoke Seasonal Box
                </span>
                <span className="px-2 py-0.5 bg-[#F2F1EE] text-[#1C1C1C] border border-[#EAE8E4] text-[9px] font-mono font-bold uppercase">
                  Save 15% Recurring
                </span>
              </div>

              {/* Selected List Breakdown */}
              <div className="space-y-2">
                <span className="text-[10px] uppercase tracking-[0.2em] text-[#777777] font-mono block">
                  Contents in your delivery:
                </span>
                {selectedProducts.map((p, i) => (
                  <div key={p.id} className="flex items-center justify-between text-xs py-1.5 px-3 bg-[#F8F7F4] border border-[#EAE8E4]">
                    <span className="text-[#1C1C1C] text-xs">
                      {i + 1}. {p.name} (Refill)
                    </span>
                    <span className="font-serif text-[#1C1C1C] font-medium">${p.refillPrice}</span>
                  </div>
                ))}
              </div>

              {/* Cadence Selector */}
              <div className="space-y-2">
                <span className="text-[10px] uppercase tracking-[0.2em] text-[#777777] font-mono block">
                  Select Refill Cadence:
                </span>
                <div className="grid grid-cols-3 gap-2 text-xs">
                  {[
                    { id: '60', label: '60 Days' },
                    { id: '90', label: '90 Days' },
                    { id: '120', label: '120 Days' },
                  ].map(cad => (
                    <button
                      key={cad.id}
                      id={`btn-cadence-${cad.id}`}
                      onClick={() => {
                        sound.playSubtleClick();
                        setCadence(cad.id as typeof cadence);
                      }}
                      className={`py-2 px-1 text-center text-[10px] font-mono uppercase tracking-wider transition-all cursor-pointer ${
                        cadence === cad.id
                          ? 'bg-[#1C1C1C] text-white font-medium'
                          : 'bg-[#F8F7F4] border border-[#EAE8E4] text-[#777777] hover:text-[#1C1C1C]'
                      }`}
                    >
                      {cad.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Complimentary Refill Gift */}
              <div className="p-3 bg-[#F2F1EE] border border-[#EAE8E4] text-xs text-[#555555] space-y-1">
                <div className="flex items-center gap-1.5 text-[#1C1C1C] font-medium">
                  <Award className="w-4 h-4 text-[#B9975B]" />
                  <span>Included in First Delivery:</span>
                </div>
                <p className="text-[10px] text-[#777777] leading-relaxed">
                  • Solid Champagne Brass Pouring Funnel ($28 value)<br />
                  • 2x Hand-Stitched Organic Polishing Chamois cloths
                </p>
              </div>

              {/* Eco Impact Stats */}
              <div className="flex items-center justify-between text-xs py-2 px-3 bg-[#F8F7F4] border border-[#EAE8E4] text-[#1C1C1C]">
                <span className="flex items-center gap-1.5 text-[10px] font-mono">
                  <Droplets className="w-3.5 h-3.5 text-[#B9975B]" />
                  Eliminates {plasticEliminated}g virgin plastic/cycle
                </span>
                <span className="font-mono text-[9px] uppercase tracking-wider text-[#B9975B] font-bold">100% Neutral</span>
              </div>

              {/* Pricing & Subscribe Action Button */}
              <div className="pt-2 border-t border-[#EAE8E4] flex items-center justify-between gap-4">
                <div>
                  <span className="text-[#888888] text-[10px] line-through block font-mono">
                    ${rawTotal}
                  </span>
                  <span className="text-2xl font-serif font-light text-[#1C1C1C]">
                    ${finalPrice}
                  </span>
                  <span className="text-[9px] text-[#888888] block font-mono">/ every {cadence} days</span>
                </div>

                <AnimatedButton
                  id="btn-subscribe-box"
                  variant="primary-solid-gold"
                  size="md"
                  soundType="cart"
                  onClick={handleSubscribe}
                  icon={isAdded ? <Check className="w-4 h-4 text-white" /> : <ShoppingBag className="w-3.5 h-3.5" />}
                  className="flex-1 text-[10px] py-3.5 font-medium tracking-[0.25em]"
                >
                  {isAdded ? 'Enrolled' : 'Initiate Box'}
                </AnimatedButton>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
