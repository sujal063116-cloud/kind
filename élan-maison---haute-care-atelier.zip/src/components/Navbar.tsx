import React, { useState } from 'react';
import { ShoppingBag, Search, Sparkles, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { SensoryAudioHud } from './SensoryAudioHud';
import { AnimatedButton } from './AnimatedButton';
import { Product } from '../types';

interface NavbarProps {
  activeCategory: string;
  onSelectCategory: (cat: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenConcierge: () => void;
  onOpenSoundStudio: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeCategory,
  onSelectCategory,
  cartCount,
  onOpenCart,
  onOpenConcierge,
  onOpenSoundStudio,
  searchQuery,
  onSearchChange,
  products,
  onSelectProduct,
}) => {
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  const categories = [
    { id: 'all', label: 'All Formulations' },
    { id: 'culinary', label: 'Culinary & Dish' },
    { id: 'surface', label: 'Stone & Surfaces' },
    { id: 'laundry', label: 'Linen & Silk' },
    { id: 'atmosphere', label: 'Atmosphere Mists' },
    { id: 'utensils', label: 'Brass Utensils' },
    { id: 'sets', label: 'Master Vaults' },
  ];

  const searchResults = searchQuery.trim()
    ? products.filter(
        p =>
          p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.fragranceFamily.toLowerCase().includes(searchQuery.toLowerCase()) ||
          p.notes.top.some(n => n.toLowerCase().includes(searchQuery.toLowerCase())) ||
          p.surfaceSuitability.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  return (
    <header className="sticky top-0 z-40 w-full bg-[#F8F7F4]/90 backdrop-blur-xl border-b border-[#EAE8E4] transition-all duration-300">
      {/* Top Luxury Announcement Banner */}
      <div className="bg-[#F2F1EE] border-b border-[#EAE8E4] py-1.5 px-4 text-center text-[10px] tracking-[0.4em] text-[#555555] flex items-center justify-center gap-3 uppercase font-medium">
        <span className="hidden sm:inline-block w-1 h-1 bg-[#B9975B]" />
        <span>COMPLIMENTARY GRASSE SCENT VIAL SET & ENGRAVED SOLID BRASS PUMP ON ORDERS OVER $100</span>
        <span className="hidden sm:inline-block w-1 h-1 bg-[#B9975B]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-4">
          {/* Left: Brand Identity */}
          <div
            onClick={() => onSelectCategory('all')}
            className="cursor-pointer group flex flex-col justify-center select-none"
          >
            <div className="flex items-center gap-2">
              <span className="font-serif text-2xl sm:text-3xl font-light tracking-[0.3em] text-[#1C1C1C] group-hover:text-[#B9975B] transition-colors duration-300">
                ÉLAN MAISON
              </span>
              <span className="w-1.5 h-1.5 bg-[#B9975B] group-hover:scale-125 transition-transform duration-300" />
            </div>
            <span className="text-[8px] uppercase tracking-[0.4em] text-[#888888] font-medium -mt-0.5">
              Haute Botanique · Grasse & Paris
            </span>
          </div>

          {/* Center: Sensory Diagnostic Quick Action (Desktop) */}
          <div className="hidden lg:flex items-center gap-3">
            <AnimatedButton
              id="btn-nav-concierge-trigger"
              variant="pill-scent"
              size="sm"
              soundType="droplet"
              onClick={onOpenConcierge}
              icon={<Sparkles className="w-3.5 h-3.5 text-[#B9975B]" />}
              className="text-[10px] px-4 py-2 border-[#D8D4CC] text-[#1C1C1C] bg-[#FFFFFF] shadow-sm tracking-[0.25em]"
            >
              Botanical Diagnostic Matcher
            </AnimatedButton>
          </div>

          {/* Right: Controls (Audio HUD, Search, Bag) */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Sensory Web Audio Engine Widget */}
            <SensoryAudioHud onOpenSoundStudio={onOpenSoundStudio} />

            {/* Search Trigger Button */}
            <AnimatedButton
              id="btn-nav-search-trigger"
              variant="icon-round"
              size="icon"
              soundType="click"
              onClick={() => setIsSearchOpen(!isSearchOpen)}
              title="Search Formulations & Notes"
              aria-label="Search Formulations & Notes"
            >
              {isSearchOpen ? <X className="w-4 h-4" /> : <Search className="w-4 h-4" />}
            </AnimatedButton>

            {/* Cart Button with spring badge counter */}
            <AnimatedButton
              id="btn-nav-open-cart"
              variant="primary-solid-gold"
              size="md"
              soundType="modal"
              onClick={onOpenCart}
              className="px-4 py-2 text-[10px] tracking-[0.25em] font-semibold"
              icon={<ShoppingBag className="w-3.5 h-3.5" />}
            >
              <span className="hidden sm:inline">Bag</span>
              <motion.span
                key={cartCount}
                initial={{ scale: 0.6, rotate: -15 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ type: 'spring', stiffness: 500, damping: 15 }}
                className="ml-1.5 px-2 py-0.5 bg-[#B9975B] text-white text-[10px] font-bold font-mono"
              >
                {cartCount}
              </motion.span>
            </AnimatedButton>
          </div>
        </div>

        {/* Category Navigation Strip */}
        <nav className="flex items-center gap-2 sm:gap-6 overflow-x-auto py-2.5 scrollbar-none border-t border-[#EAE8E4] text-[10px] uppercase tracking-[0.3em] font-medium text-[#777777]">
          {categories.map(cat => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                id={`btn-nav-cat-${cat.id}`}
                onClick={() => onSelectCategory(cat.id)}
                className={`
                  relative py-1.5 px-2.5 whitespace-nowrap transition-colors duration-300 focus:outline-none cursor-pointer
                  ${isActive ? 'text-[#1C1C1C] font-semibold' : 'hover:text-[#B9975B]'}
                `}
              >
                <span>{cat.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="activeCategoryUnderline"
                    className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-[#B9975B]"
                    transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Slide-Down Search Overlay */}
      <AnimatePresence>
        {isSearchOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="border-t border-[#EAE8E4] bg-[#FFFFFF]/98 backdrop-blur-2xl overflow-hidden shadow-lg"
          >
            <div className="max-w-4xl mx-auto p-4 sm:p-6">
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#B9975B]" />
                <input
                  id="input-global-search"
                  type="text"
                  placeholder="Search by surface (e.g. Marble, Linen, Brass) or scent note (Neroli, Santal, Fig)..."
                  value={searchQuery}
                  onChange={e => onSearchChange(e.target.value)}
                  autoFocus
                  className="w-full bg-[#F8F7F4] border border-[#EAE8E4] focus:border-[#B9975B] pl-12 pr-10 py-3 text-xs text-[#1C1C1C] placeholder-[#888888] focus:outline-none"
                />
                {searchQuery && (
                  <button
                    id="btn-clear-search-query"
                    onClick={() => onSearchChange('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-[#888888] hover:text-[#1C1C1C]"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Instant Search Results Dropdown */}
              {searchQuery.trim() && (
                <div className="mt-4 pt-3 border-t border-[#EAE8E4]">
                  <p className="text-[10px] uppercase font-mono tracking-widest text-[#888888] mb-2">
                    Found {searchResults.length} matching formulation(s):
                  </p>
                  {searchResults.length === 0 ? (
                    <p className="text-xs text-[#888888] italic py-4 text-center">
                      No formulations match your query. Try searching &apos;Neroli&apos;, &apos;Marble&apos;, or &apos;Linen&apos;.
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-64 overflow-y-auto">
                      {searchResults.map(p => (
                        <div
                          key={p.id}
                          onClick={() => {
                            onSelectProduct(p);
                            setIsSearchOpen(false);
                          }}
                          className="flex items-center gap-3 p-2.5 bg-[#F8F7F4] hover:bg-[#F2F1EE] border border-[#EAE8E4] hover:border-[#B9975B] cursor-pointer transition-all"
                        >
                          <img
                            src={p.image}
                            alt={p.name}
                            className="w-12 h-12 object-contain bg-white p-1 border border-[#EAE8E4]"
                          />
                          <div className="flex-1 min-w-0">
                            <h4 className="text-xs font-medium text-[#1C1C1C] truncate">{p.name}</h4>
                            <p className="text-[10px] text-[#B9975B] tracking-wider uppercase font-mono truncate">{p.fragranceFamily}</p>
                            <span className="text-xs font-serif text-[#1C1C1C]">${p.price}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
