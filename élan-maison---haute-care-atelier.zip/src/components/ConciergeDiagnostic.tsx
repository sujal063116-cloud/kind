import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, X, Check, ArrowRight, RefreshCw, ShoppingBag, ShieldCheck, Heart } from 'lucide-react';
import { Product } from '../types';
import { AnimatedButton } from './AnimatedButton';
import { sound } from '../utils/audio';

interface ConciergeDiagnosticProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onAddBundleToCart: (products: Product[]) => void;
}

export const ConciergeDiagnostic: React.FC<ConciergeDiagnosticProps> = ({
  isOpen,
  onClose,
  products,
  onAddBundleToCart,
}) => {
  const [step, setStep] = useState<1 | 2 | 3 | 4>(1);
  const [selectedSurface, setSelectedSurface] = useState<string>('marble');
  const [selectedScent, setSelectedScent] = useState<string>('neroli');
  const [selectedRitual, setSelectedRitual] = useState<string>('sanctuary');
  const [isAddingBundle, setIsAddingBundle] = useState(false);

  if (!isOpen) return null;

  const surfaceOptions = [
    {
      id: 'marble',
      title: 'Carrara Marble & Quartz',
      desc: 'Sensitive, unsealed porous stones requiring neutral pH & non-acidic bio-enzymes.',
    },
    {
      id: 'wood',
      title: 'French Oak & Solid Walnut',
      desc: 'Heritage timber demanding moisturizing plant oils and satin patina preservation.',
    },
    {
      id: 'linens',
      title: 'Mulberry Silk & Fine Cottons',
      desc: 'Luxury textiles requiring fiber-smoothing enzymes and zero optical brighteners.',
    },
    {
      id: 'culinary',
      title: 'Chef Cookware & Crystal',
      desc: 'Copper, cast iron, and crystal needing rapid lipid breakdown with squalane hand-care.',
    },
  ];

  const scentOptions = [
    {
      id: 'neroli',
      title: 'Sunlit Mediterranean Citrus & Neroli',
      desc: 'Bright, invigorating, effervescent with Calabrian bergamot & white rosemary.',
    },
    {
      id: 'santal',
      title: 'Smoked Sandalwood & Amber Sanctuary',
      desc: 'Deep, meditative, warm cashmere notes with Mysore sandalwood & cardamon.',
    },
    {
      id: 'fig',
      title: 'Botanical Fig & Crisp Garden Herbs',
      desc: 'Lush, green, dew-kissed Provençal fig leaf with cyclamen and clean vetiver.',
    },
    {
      id: 'cedar',
      title: 'Wild Atlas Cedar & Pure Vetiver',
      desc: 'Air-purifying forest phytoncides, silver fir needle, and restorative dark patchouli.',
    },
  ];

  const ritualOptions = [
    {
      id: 'sanctuary',
      title: 'Atmospheric Sanctuary Living',
      desc: 'Transforming daily domestic tidying into peaceful olfactory meditation.',
    },
    {
      id: 'hospitality',
      title: 'Grand Entertaining & Culinary Elegance',
      desc: 'Flawless table settings, crystal-clear glass, and pristine kitchen island prep.',
    },
    {
      id: 'eco-mastery',
      title: 'Zero-Waste Refill Purity',
      desc: 'Eliminating all single-use plastics with heirloom flacons and bio-refills.',
    },
  ];

  // Dynamic recommendation matching based on choices
  const getPrescription = () => {
    let primary = products[0]; // Surface Elixir
    let companion = products[1]; // Dish Nectar
    let atmospheric = products[3]; // Room Mist

    if (selectedSurface === 'linens') {
      primary = products[2]; // Laundry
      companion = products[3]; // Mist
      atmospheric = products[0];
    } else if (selectedSurface === 'culinary') {
      primary = products[1]; // Dish Nectar
      companion = products[6]; // Brass Brush
      atmospheric = products[0];
    } else if (selectedSurface === 'marble') {
      primary = products[0]; // Surface
      companion = products[4]; // Stone Balm
      atmospheric = products[3];
    }

    const bundleItems = [primary, companion, atmospheric];
    const originalPrice = bundleItems.reduce((sum, p) => sum + p.price, 0);
    const bundlePrice = Math.round(originalPrice * 0.8); // 20% Atelier Discount

    return {
      bundleItems,
      originalPrice,
      bundlePrice,
      savings: originalPrice - bundlePrice,
      matchScore: 99.4,
    };
  };

  const prescription = getPrescription();

  const handleNext = () => {
    sound.playDroplet();
    setStep(prev => (prev < 4 ? ((prev + 1) as typeof step) : 4));
  };

  const handleBack = () => {
    sound.playSubtleClick();
    setStep(prev => (prev > 1 ? ((prev - 1) as typeof step) : 1));
  };

  const handleReset = () => {
    sound.playSubtleClick();
    setStep(1);
  };

  const handleAcquireBundle = () => {
    setIsAddingBundle(true);
    onAddBundleToCart(prescription.bundleItems);
    setTimeout(() => {
      setIsAddingBundle(false);
      onClose();
    }, 1200);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-3xl bg-[#FFFFFF] border border-[#EAE8E4] p-6 sm:p-8 shadow-[0_25px_80px_rgba(0,0,0,0.15)] overflow-hidden text-[#1C1C1C] my-8"
        >
          {/* Close Button */}
          <button
            id="btn-close-concierge"
            onClick={() => {
              sound.playSubtleClick();
              onClose();
            }}
            className="absolute top-5 right-5 z-20 p-2 text-[#777777] hover:text-[#1C1C1C] hover:bg-[#F2F1EE] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Header */}
          <div className="mb-6 text-center max-w-xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#F8F7F4] border border-[#EAE8E4] text-[#B9975B] text-[10px] font-mono tracking-[0.3em] uppercase mb-2">
              <Sparkles className="w-3.5 h-3.5 text-[#B9975B]" />
              Le Diagnostic Botanique
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif font-light text-[#1C1C1C]">
              Cleaning & Olfactory Consultation
            </h2>
            <p className="text-xs text-[#555555] mt-1 font-sans">
              Answer 3 bespoke questions to diagnose your architectural materials and olfactory desires.
            </p>

            {/* Step Progress Dots */}
            <div className="flex items-center justify-center gap-2 mt-4">
              {[1, 2, 3, 4].map(s => (
                <div
                  key={s}
                  className={`h-1 transition-all duration-300 ${
                    step === s
                      ? 'w-8 bg-[#1C1C1C]'
                      : step > s
                      ? 'w-4 bg-[#B9975B]'
                      : 'w-4 bg-[#EAE8E4]'
                  }`}
                />
              ))}
            </div>
          </div>

          {/* STEP 1: Surface Architecture */}
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h3 className="text-sm font-serif italic text-[#1C1C1C] text-center">
                Question 01: What is the primary luxury material in your sanctuary?
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {surfaceOptions.map(opt => (
                  <div
                    key={opt.id}
                    id={`opt-surface-${opt.id}`}
                    onClick={() => {
                      sound.playSubtleClick();
                      setSelectedSurface(opt.id);
                    }}
                    className={`p-4 border transition-all cursor-pointer select-none bg-[#FFFFFF] ${
                      selectedSurface === opt.id
                        ? 'border-[#B9975B] shadow-[0_4px_20px_rgba(185,151,91,0.15)] ring-1 ring-[#B9975B]'
                        : 'border-[#EAE8E4] hover:border-[#B9975B]/60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-xs font-serif font-semibold text-[#1C1C1C]">{opt.title}</h4>
                      {selectedSurface === opt.id && <Check className="w-4 h-4 text-[#B9975B]" />}
                    </div>
                    <p className="text-[10px] text-[#555555] leading-relaxed">{opt.desc}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* STEP 2: Olfactory Mood */}
          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h3 className="text-sm font-serif italic text-[#1C1C1C] text-center">
                Question 02: Which fragrance atmosphere calls to your senses?
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {scentOptions.map(opt => (
                  <div
                    key={opt.id}
                    id={`opt-scent-${opt.id}`}
                    onClick={() => {
                      sound.playDroplet();
                      setSelectedScent(opt.id);
                    }}
                    className={`p-4 border transition-all cursor-pointer select-none bg-[#FFFFFF] ${
                      selectedScent === opt.id
                        ? 'border-[#B9975B] shadow-[0_4px_20px_rgba(185,151,91,0.15)] ring-1 ring-[#B9975B]'
                        : 'border-[#EAE8E4] hover:border-[#B9975B]/60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-xs font-serif font-semibold text-[#1C1C1C]">{opt.title}</h4>
                      {selectedScent === opt.id && <Check className="w-4 h-4 text-[#B9975B]" />}
                    </div>
                    <p className="text-[10px] text-[#555555] leading-relaxed">{opt.desc}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* STEP 3: Priority Domestic Ritual */}
          {step === 3 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-4"
            >
              <h3 className="text-sm font-serif italic text-[#1C1C1C] text-center">
                Question 03: What is your primary domestic aspiration?
              </h3>
              <div className="space-y-3">
                {ritualOptions.map(opt => (
                  <div
                    key={opt.id}
                    id={`opt-ritual-${opt.id}`}
                    onClick={() => {
                      sound.playSubtleClick();
                      setSelectedRitual(opt.id);
                    }}
                    className={`p-4 border transition-all cursor-pointer select-none bg-[#FFFFFF] ${
                      selectedRitual === opt.id
                        ? 'border-[#B9975B] shadow-[0_4px_20px_rgba(185,151,91,0.15)] ring-1 ring-[#B9975B]'
                        : 'border-[#EAE8E4] hover:border-[#B9975B]/60'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="text-xs font-serif font-semibold text-[#1C1C1C]">{opt.title}</h4>
                      {selectedRitual === opt.id && <Check className="w-4 h-4 text-[#B9975B]" />}
                    </div>
                    <p className="text-[10px] text-[#555555] leading-relaxed">{opt.desc}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {/* STEP 4: Prescription Results */}
          {step === 4 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="space-y-5"
            >
              <div className="p-5 bg-[#F8F7F4] border border-[#EAE8E4]">
                <div className="flex items-center justify-between pb-3 mb-3 border-b border-[#EAE8E4]">
                  <div>
                    <span className="text-[9px] uppercase font-mono tracking-[0.2em] text-[#B9975B] block font-bold">
                      Prescription No. {Math.floor(Math.random() * 8000 + 1000)}
                    </span>
                    <h4 className="text-sm font-serif font-semibold text-[#1C1C1C]">
                      The Bespoke Atelier Regimen
                    </h4>
                  </div>
                  <span className="px-2.5 py-1 bg-[#1C1C1C] text-white text-[10px] font-mono font-medium">
                    {prescription.matchScore}% Resonance
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {prescription.bundleItems.map(p => (
                    <div key={p.id} className="p-3 bg-[#FFFFFF] border border-[#EAE8E4] flex flex-col items-center text-center">
                      <img src={p.image} alt={p.name} className="w-16 h-16 object-contain mb-2" />
                      <h5 className="text-xs font-serif font-medium text-[#1C1C1C] truncate w-full">{p.name}</h5>
                      <span className="text-[9px] text-[#B9975B] font-mono tracking-wider">{p.fragranceFamily}</span>
                      <span className="text-xs font-serif text-[#1C1C1C] mt-1">${p.price}</span>
                    </div>
                  ))}
                </div>

                <div className="mt-4 pt-3 border-t border-[#EAE8E4] flex flex-col sm:flex-row items-center justify-between text-xs gap-2">
                  <div>
                    <span className="text-[#888888] line-through mr-2 font-mono text-xs">
                      ${prescription.originalPrice}
                    </span>
                    <span className="text-base font-serif font-light text-[#1C1C1C]">
                      ${prescription.bundlePrice}
                    </span>
                    <span className="ml-2 text-[10px] text-[#B9975B] font-medium font-mono">
                      (20% Consultation Privilege · Save ${prescription.savings})
                    </span>
                  </div>
                  <span className="text-[10px] text-[#777777] flex items-center gap-1 font-mono uppercase">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#B9975B]" /> Free Brass Funnel
                  </span>
                </div>
              </div>
            </motion.div>
          )}

          {/* Navigation Controls */}
          <div className="mt-6 pt-4 border-t border-[#EAE8E4] flex items-center justify-between gap-3">
            {step > 1 && step < 4 ? (
              <AnimatedButton
                id="btn-concierge-back"
                variant="outline-minimal"
                size="sm"
                soundType="click"
                onClick={handleBack}
                className="text-[10px] tracking-[0.2em]"
              >
                Previous Step
              </AnimatedButton>
            ) : step === 4 ? (
              <AnimatedButton
                id="btn-concierge-reset"
                variant="outline-minimal"
                size="sm"
                soundType="click"
                onClick={handleReset}
                icon={<RefreshCw className="w-3.5 h-3.5" />}
                className="text-[10px] tracking-[0.2em]"
              >
                Restart
              </AnimatedButton>
            ) : (
              <div />
            )}

            {step < 4 ? (
              <AnimatedButton
                id="btn-concierge-next"
                variant="primary-solid-gold"
                size="md"
                soundType="droplet"
                onClick={handleNext}
                icon={<ArrowRight className="w-3.5 h-3.5" />}
                iconPosition="right"
                className="px-6 text-[10px] tracking-[0.25em]"
              >
                {step === 3 ? 'Synthesize Regimen' : 'Proceed'}
              </AnimatedButton>
            ) : (
              <AnimatedButton
                id="btn-acquire-prescribed-bundle"
                variant="primary-solid-gold"
                size="lg"
                soundType="cart"
                onClick={handleAcquireBundle}
                icon={isAddingBundle ? <Check className="w-4 h-4 text-white" /> : <ShoppingBag className="w-3.5 h-3.5" />}
                className="text-[10px] px-8 font-medium tracking-[0.25em]"
              >
                {isAddingBundle ? 'Curated to Bag' : `Acquire 3-Piece Regimen · $${prescription.bundlePrice}`}
              </AnimatedButton>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
