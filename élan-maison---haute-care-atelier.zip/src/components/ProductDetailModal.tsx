import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Star, Droplets, ShieldCheck, Check, Sparkles, ShoppingBag, Plus, Minus, Layers, Feather } from 'lucide-react';
import { Product } from '../types';
import { AnimatedButton } from './AnimatedButton';
import { sound } from '../utils/audio';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, isRefill: boolean, engraving?: string, quantity?: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  onAddToCart,
}) => {
  const [selectedFormat, setSelectedFormat] = useState<'vessel' | 'refill'>('vessel');
  const [quantity, setQuantity] = useState(1);
  const [engravingText, setEngravingText] = useState('');
  const [activeTab, setActiveTab] = useState<'olfactory' | 'surfaces' | 'ritual' | 'eco'>('olfactory');
  const [isAdded, setIsAdded] = useState(false);

  if (!isOpen || !product) return null;

  const currentPrice = selectedFormat === 'vessel' ? product.price : product.refillPrice;
  const totalPrice = currentPrice * quantity;

  const handleAdd = () => {
    onAddToCart(product, selectedFormat === 'refill', engravingText.trim() || undefined, quantity);
    setIsAdded(true);
    setTimeout(() => {
      setIsAdded(false);
      onClose();
    }, 1200);
  };

  const handleQtyChange = (delta: number) => {
    sound.playSubtleClick();
    setQuantity(prev => Math.max(1, Math.min(10, prev + delta)));
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/50 backdrop-blur-md overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 15 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-4xl bg-[#FFFFFF] border border-[#EAE8E4] p-6 sm:p-8 shadow-[0_25px_80px_rgba(0,0,0,0.15)] overflow-hidden text-[#1C1C1C] my-auto"
        >
          {/* Close Button */}
          <button
            id="btn-close-product-detail-modal"
            onClick={() => {
              sound.playSubtleClick();
              onClose();
            }}
            className="absolute top-5 right-5 z-20 p-2 text-[#777777] hover:text-[#1C1C1C] hover:bg-[#F2F1EE] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            {/* Left: Interactive Bottle & Engraving Preview Stage */}
            <div className="md:col-span-5 flex flex-col items-center justify-center space-y-4">
              <div className="relative w-full aspect-[4/5] bg-[#F2F1EE] border border-[#EAE8E4] p-6 flex items-center justify-center overflow-hidden">
                <motion.img
                  src={product.image}
                  alt={product.name}
                  className="max-h-[280px] object-contain drop-shadow-[0_15px_30px_rgba(0,0,0,0.1)]"
                  animate={{ scale: [1, 1.02, 1] }}
                  transition={{ repeat: Infinity, duration: 6, ease: 'easeInOut' }}
                />

                {/* Live Brass Collar Laser Engraving Simulation */}
                {engravingText.trim() && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="absolute bottom-4 inset-x-4 p-2 bg-[#FFFFFF] border border-[#B9975B] text-center shadow-sm"
                  >
                    <span className="text-[8px] uppercase font-mono tracking-widest text-[#777777] block">
                      Custom Laser Monogram
                    </span>
                    <span className="text-xs font-serif tracking-[0.2em] text-[#1C1C1C] font-bold">
                      &quot;{engravingText.toUpperCase()}&quot;
                    </span>
                  </motion.div>
                )}
              </div>

              {/* Eco Credential Badges */}
              <div className="w-full flex items-center justify-around py-2 px-3 bg-[#F8F7F4] border border-[#EAE8E4] text-[10px] font-mono text-[#555555]">
                <span className="flex items-center gap-1">
                  <Droplets className="w-3 h-3 text-[#B9975B]" />
                  -{product.ecoMetrics.plasticSavedGrams}g Plastic
                </span>
                <span className="flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3 text-[#B9975B]" />
                  100% Bio-Active
                </span>
              </div>
            </div>

            {/* Right: Technical Formulation Dossier & Controls */}
            <div className="md:col-span-7 space-y-5">
              {/* Product Header */}
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-[0.25em] text-[#B9975B] flex items-center gap-1.5 font-semibold">
                    <Sparkles className="w-3.5 h-3.5" />
                    {product.fragranceFamily}
                  </span>
                  <div className="flex items-center gap-1 text-xs">
                    <Star className="w-3.5 h-3.5 fill-[#B9975B] text-[#B9975B]" />
                    <span className="font-mono text-[#1C1C1C] font-medium">{product.rating}</span>
                    <span className="text-[#888888] text-[10px]">({product.reviewsCount} reviews)</span>
                  </div>
                </div>

                <h2 className="text-2xl sm:text-3xl font-serif font-light text-[#1C1C1C] tracking-tight mt-1">
                  {product.name}
                </h2>
                <p className="text-xs font-serif italic text-[#777777]">
                  {product.frenchTitle} — {product.volume}
                </p>
                <p className="text-xs text-[#555555] mt-2 leading-relaxed font-sans">
                  {product.description}
                </p>
              </div>

              {/* Tab Navigation */}
              <div className="grid grid-cols-4 gap-1 p-0.5 bg-[#F8F7F4] border border-[#EAE8E4] text-[10px] uppercase font-mono tracking-wider">
                {[
                  { id: 'olfactory', label: 'Olfactory' },
                  { id: 'surfaces', label: 'Surfaces' },
                  { id: 'ritual', label: 'Ritual' },
                  { id: 'eco', label: 'Eco Impact' },
                ].map(tab => (
                  <button
                    key={tab.id}
                    id={`btn-modal-tab-${tab.id}`}
                    onClick={() => {
                      sound.playSubtleClick();
                      setActiveTab(tab.id as typeof activeTab);
                    }}
                    className={`py-1.5 px-1 text-center transition-all cursor-pointer ${
                      activeTab === tab.id
                        ? 'bg-[#1C1C1C] text-white font-medium'
                        : 'text-[#777777] hover:text-[#1C1C1C]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Tab Details Content */}
              <div className="p-3.5 bg-[#F8F7F4] border border-[#EAE8E4] min-h-[110px] text-xs">
                {activeTab === 'olfactory' && (
                  <div className="space-y-2">
                    <div>
                      <span className="text-[9px] uppercase font-mono text-[#B9975B] block font-bold">
                        Top Notes (Immediate Impression)
                      </span>
                      <span className="text-[#1C1C1C] text-xs font-serif italic">{product.notes.top.join(' · ')}</span>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase font-mono text-[#B9975B] block font-bold">
                        Heart Notes (Aromatic Aura)
                      </span>
                      <span className="text-[#1C1C1C] text-xs font-serif italic">{product.notes.heart.join(' · ')}</span>
                    </div>
                    <div>
                      <span className="text-[9px] uppercase font-mono text-[#B9975B] block font-bold">
                        Base Notes (Lasting Trace)
                      </span>
                      <span className="text-[#1C1C1C] text-xs font-serif italic">{product.notes.base.join(' · ')}</span>
                    </div>
                  </div>
                )}

                {activeTab === 'surfaces' && (
                  <div className="grid grid-cols-2 gap-2">
                    {product.surfaceSuitability.map((surface, i) => (
                      <div key={i} className="flex items-center gap-1.5 text-[#555555] text-xs">
                        <Check className="w-3.5 h-3.5 text-[#B9975B] shrink-0" />
                        <span>{surface}</span>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === 'ritual' && (
                  <div className="space-y-2 text-[#555555] text-xs">
                    <div className="flex items-start gap-2">
                      <span className="font-serif italic text-[#B9975B]">01.</span>
                      <p>Mist lightly from 20cm onto surface or microfiber cloth.</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="font-serif italic text-[#B9975B]">02.</span>
                      <p>Allow the active bio-enzymes 5 seconds to dissolve lipids.</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <span className="font-serif italic text-[#B9975B]">03.</span>
                      <p>Buff in sweeping circular motion with our organic cotton polishing chamois.</p>
                    </div>
                  </div>
                )}

                {activeTab === 'eco' && (
                  <div className="space-y-2 text-[#555555] text-xs">
                    <p className="flex items-center gap-2">
                      <Feather className="w-3.5 h-3.5 text-[#B9975B]" />
                      Saves approx. <strong>{product.ecoMetrics.plasticSavedGrams}g</strong> of virgin plastic per refill cycle.
                    </p>
                    <p className="flex items-center gap-2">
                      <Layers className="w-3.5 h-3.5 text-[#B9975B]" />
                      <strong>{product.ecoMetrics.biodegradablePercent}%</strong> readily biodegradable in aquatic ecosystems within 28 days.
                    </p>
                  </div>
                )}
              </div>

              {/* Vessel vs Refill Selector */}
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase font-mono tracking-wider text-[#777777]">
                  Select Format:
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    id="btn-modal-format-vessel"
                    onClick={() => {
                      sound.playSubtleClick();
                      setSelectedFormat('vessel');
                    }}
                    className={`p-2.5 border text-left transition-all cursor-pointer ${
                      selectedFormat === 'vessel'
                        ? 'bg-[#1C1C1C] text-white border-[#1C1C1C]'
                        : 'bg-[#FFFFFF] border-[#EAE8E4] text-[#555555] hover:border-[#B9975B]'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-medium">Heirloom Amber Glass</span>
                      <span className={`text-xs font-serif ${selectedFormat === 'vessel' ? 'text-white' : 'text-[#1C1C1C]'}`}>${product.price}</span>
                    </div>
                    <span className={`text-[10px] ${selectedFormat === 'vessel' ? 'text-neutral-300' : 'text-[#888888]'}`}>Includes solid brass pump</span>
                  </button>

                  <button
                    id="btn-modal-format-refill"
                    onClick={() => {
                      sound.playSubtleClick();
                      setSelectedFormat('refill');
                    }}
                    className={`p-2.5 border text-left transition-all cursor-pointer ${
                      selectedFormat === 'refill'
                        ? 'bg-[#1C1C1C] text-white border-[#1C1C1C]'
                        : 'bg-[#FFFFFF] border-[#EAE8E4] text-[#555555] hover:border-[#B9975B]'
                    }`}
                  >
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-medium">Eco-Refill Pouch</span>
                      <span className={`text-xs font-serif ${selectedFormat === 'refill' ? 'text-white' : 'text-[#1C1C1C]'}`}>${product.refillPrice}</span>
                    </div>
                    <span className={`text-[10px] ${selectedFormat === 'refill' ? 'text-[#B9975B]' : 'text-[#B9975B]'}`}>Save 35% + Zero Plastic Waste</span>
                  </button>
                </div>
              </div>

              {/* Complimentary Monogram Laser Engraving */}
              {selectedFormat === 'vessel' && (
                <div className="space-y-1">
                  <div className="flex justify-between items-center text-[10px] font-mono">
                    <span className="text-[#777777]">Complimentary Brass Collar Engraving:</span>
                    <span className="text-[#B9975B]">Max 18 Characters</span>
                  </div>
                  <input
                    id="input-brass-engraving"
                    type="text"
                    maxLength={18}
                    placeholder="e.g. VILLA SAINT-TROPEZ or THE RESIDENCE"
                    value={engravingText}
                    onChange={e => setEngravingText(e.target.value)}
                    className="w-full bg-[#F8F7F4] border border-[#EAE8E4] focus:border-[#B9975B] px-3 py-2 text-xs text-[#1C1C1C] placeholder-[#999999] focus:outline-none font-mono"
                  />
                </div>
              )}

              {/* Quantity and Primary Action */}
              <div className="pt-2 flex items-center gap-3">
                {/* Quantity Buttons */}
                <div className="flex items-center bg-[#F8F7F4] border border-[#EAE8E4] p-0.5">
                  <button
                    id="btn-qty-minus"
                    onClick={() => handleQtyChange(-1)}
                    className="p-1.5 hover:bg-[#EAE8E4] text-[#555555] hover:text-[#1C1C1C] cursor-pointer"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="w-8 text-center text-xs font-mono font-bold text-[#1C1C1C]">{quantity}</span>
                  <button
                    id="btn-qty-plus"
                    onClick={() => handleQtyChange(1)}
                    className="p-1.5 hover:bg-[#EAE8E4] text-[#555555] hover:text-[#1C1C1C] cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Add to Bag Action with Animated Particle Sparks & Sound */}
                <AnimatedButton
                  id="btn-modal-add-to-cart"
                  variant="primary-solid-gold"
                  size="md"
                  soundType="cart"
                  onClick={handleAdd}
                  icon={isAdded ? <Check className="w-4 h-4 text-white" /> : <ShoppingBag className="w-3.5 h-3.5" />}
                  className="flex-1 text-[10px] py-3 font-medium tracking-[0.25em]"
                >
                  {isAdded ? 'Curated to Bag' : `Acquire Formulation · $${totalPrice}`}
                </AnimatedButton>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
