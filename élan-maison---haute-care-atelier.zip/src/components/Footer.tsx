import React, { useState } from 'react';
import { Sparkles, Check, Heart, ShieldCheck, Droplets, Volume2 } from 'lucide-react';
import { AnimatedButton } from './AnimatedButton';
import { sound } from '../utils/audio';

interface FooterProps {
  onOpenSoundStudio: () => void;
  onOpenConcierge: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenSoundStudio, onOpenConcierge }) => {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    sound.playAddCart();
    setIsSubscribed(true);
    setTimeout(() => {
      setEmail('');
      setIsSubscribed(false);
    }, 4000);
  };

  return (
    <footer className="bg-[#1C1C1C] text-[#999999] border-t border-[#333333] pt-16 pb-12 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        
        {/* Newsletter & Brand Invitation */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 pb-12 border-b border-[#333333] items-center">
          <div className="lg:col-span-6 space-y-2">
            <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#B9975B] block font-bold">
              L&apos;Invitation Privilège
            </span>
            <h3 className="text-2xl sm:text-3xl font-serif font-light text-[#F8F7F4]">
              Join the ÉLAN Maison Society
            </h3>
            <p className="text-xs text-[#999999] max-w-md font-sans">
              Receive private invitations to seasonal harvest batches, rare essential oil extractions from Grasse, and bespoke cleaning masterclasses.
            </p>
          </div>

          <div className="lg:col-span-6">
            {isSubscribed ? (
              <div className="p-4 bg-[#262626] border border-[#B9975B] text-[#F8F7F4] flex items-center gap-2">
                <Check className="w-4 h-4 text-[#B9975B]" />
                <span className="font-serif">Merci. Your invitation has been dispatched to your residence.</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-2">
                <input
                  id="input-newsletter-email"
                  type="email"
                  required
                  placeholder="Enter your residence email address..."
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="flex-1 bg-[#262626] border border-[#444444] focus:border-[#B9975B] px-4 py-3 text-xs text-[#F8F7F4] placeholder-[#777777] focus:outline-none font-mono"
                />
                <AnimatedButton
                  id="btn-newsletter-subscribe"
                  variant="primary-solid-gold"
                  size="md"
                  soundType="cart"
                  type="submit"
                  className="text-[10px] font-medium tracking-[0.2em] px-6 py-3"
                  icon={<Sparkles className="w-3.5 h-3.5" />}
                >
                  Join Society
                </AnimatedButton>
              </form>
            )}
          </div>
        </div>

        {/* Links & Pillars */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div className="space-y-3">
            <h4 className="font-serif text-xs text-[#F8F7F4] uppercase tracking-[0.2em]">The Atelier</h4>
            <ul className="space-y-2 text-[#999999]">
              <li><button onClick={onOpenConcierge} className="hover:text-[#B9975B] transition-colors cursor-pointer text-left">Scent & Surface Concierge</button></li>
              <li><span className="hover:text-[#B9975B] transition-colors cursor-pointer">Grasse Botanical Extraction</span></li>
              <li><span className="hover:text-[#B9975B] transition-colors cursor-pointer">Heirloom Brass Hardware</span></li>
              <li><span className="hover:text-[#B9975B] transition-colors cursor-pointer">Eco-Refill Architecture</span></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-serif text-xs text-[#F8F7F4] uppercase tracking-[0.2em]">Formulations</h4>
            <ul className="space-y-2 text-[#999999]">
              <li><span className="hover:text-[#B9975B] transition-colors cursor-pointer">All-Surface Bio-Elixir</span></li>
              <li><span className="hover:text-[#B9975B] transition-colors cursor-pointer">White Santal Dish Nectar</span></li>
              <li><span className="hover:text-[#B9975B] transition-colors cursor-pointer">Mulberry Silk Laundry Wash</span></li>
              <li><span className="hover:text-[#B9975B] transition-colors cursor-pointer">Atmosphere & Linen Mists</span></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-serif text-xs text-[#F8F7F4] uppercase tracking-[0.2em]">Sensory Sound</h4>
            <ul className="space-y-2 text-[#999999]">
              <li>
                <button
                  onClick={onOpenSoundStudio}
                  className="flex items-center gap-1 text-[#B9975B] hover:underline cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                  Web Audio Synthesizer Lab
                </button>
              </li>
              <li><span className="text-[#666666]">432Hz Generative Ambiance</span></li>
              <li><span className="text-[#666666]">Tactile Ceramic Micro-Harmonics</span></li>
            </ul>
          </div>

          <div className="space-y-3">
            <h4 className="font-serif text-xs text-[#F8F7F4] uppercase tracking-[0.2em]">Atelier Salons</h4>
            <p className="text-[#999999] text-[11px] leading-relaxed">
              <strong>Paris:</strong> 24 Place Vendôme, 75001<br />
              <strong>Grasse:</strong> Domaine de la Rose Botanique<br />
              <strong>New York:</strong> 740 Madison Avenue
            </p>
          </div>
        </div>

        {/* Bottom Strip */}
        <div className="pt-8 border-t border-[#333333] flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-[#777777] font-mono">
          <div className="flex items-center gap-2">
            <span>© {new Date().getFullYear()} ÉLAN MAISON ATELIER. All rights reserved.</span>
          </div>

          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1 text-[#B9975B]">
              <Droplets className="w-3 h-3" /> 100% Readily Biodegradable
            </span>
            <span className="flex items-center gap-1 text-[#B9975B]">
              <ShieldCheck className="w-3 h-3" /> Zero Phthalates
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
};
