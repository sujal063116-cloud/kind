import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, Volume2, Sparkles, Activity, ShieldCheck, Play, Bell, Droplets, Zap, CheckCircle2 } from 'lucide-react';
import { sound } from '../utils/audio';
import { AnimatedButton } from './AnimatedButton';

interface SoundDesignModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SoundDesignModal: React.FC<SoundDesignModalProps> = ({ isOpen, onClose }) => {
  const [activeTest, setActiveTest] = useState<string | null>(null);

  if (!isOpen) return null;

  const testSounds = [
    {
      id: 'subtle-click',
      title: 'Ceramic Tactile Click',
      category: 'Micro-Interaction',
      freq: '280Hz -> 80Hz Bandpass',
      description: 'Ultra-low decay impulse simulating gentle contact with handcrafted ceramic and amber glass.',
      icon: <Zap className="w-4 h-4 text-[#d4af37]" />,
      action: () => sound.playSubtleClick(),
    },
    {
      id: 'hover-shimmer',
      title: 'Ethereal Harmonic Shimmer',
      category: 'Hover Feedback',
      freq: 'E5 (659Hz) -> A5 (880Hz)',
      description: 'Soft harmonic glissando triggered on button engagement to give tactile airy lightness.',
      icon: <Sparkles className="w-4 h-4 text-amber-300" />,
      action: () => sound.playHoverShimmer(),
    },
    {
      id: 'add-cart',
      title: 'Crystalline Arpeggio Chime',
      category: 'Conversion Delight',
      freq: 'C5, E5, G5, C6 Polyphony',
      description: 'Ascending four-part harmonic chord symbolizing fulfillment of a bespoke ritual purchase.',
      icon: <Bell className="w-4 h-4 text-yellow-400" />,
      action: () => sound.playAddCart(),
    },
    {
      id: 'droplet',
      title: 'Bio-Enzyme Water Droplet',
      category: 'Botanical Note',
      freq: '700Hz -> 1480Hz Resonant',
      description: 'Pure liquid acoustic bloom evoking botanical distillations and micro-droplet extraction.',
      icon: <Droplets className="w-4 h-4 text-cyan-400" />,
      action: () => sound.playDroplet(),
    },
    {
      id: 'modal-open',
      title: 'Velvet Resonant Swell',
      category: 'Architectural Transition',
      freq: '220Hz + 440Hz Low Overtone',
      description: 'Deep warm acoustic envelope that grounds viewport drawers and dialog transitions.',
      icon: <Activity className="w-4 h-4 text-emerald-400" />,
      action: () => sound.playModalOpen(),
    },
    {
      id: 'metallic-toggle',
      title: 'Brushed Brass Switch',
      category: 'Mechanical Tactility',
      freq: '2400Hz High-Pass Latch',
      description: 'Crisp mechanical precision modeled after heavy solid champagne brass pump hardware.',
      icon: <Volume2 className="w-4 h-4 text-orange-400" />,
      action: () => sound.playMetallicToggle(),
    },
    {
      id: 'success-fanfare',
      title: 'Grand Luxury Fanfare Chord',
      category: 'Checkout Resolution',
      freq: 'Db Major 9 Spread Arpeggio',
      description: 'Warm resonant 5-tone chord resolving the transaction with celebratory elegance.',
      icon: <CheckCircle2 className="w-4 h-4 text-amber-200" />,
      action: () => sound.playSuccessCelebration(),
    },
  ];

  const handleTest = (soundItem: (typeof testSounds)[0]) => {
    setActiveTest(soundItem.id);
    soundItem.action();
    setTimeout(() => {
      setActiveTest(null);
    }, 500);
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm overflow-y-auto">
        <motion.div
          initial={{ opacity: 0, scale: 0.96, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.96, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          className="relative w-full max-w-2xl bg-[#FFFFFF] border border-[#EAE8E4] p-6 sm:p-8 shadow-[0_20px_70px_rgba(0,0,0,0.15)] overflow-hidden text-[#1C1C1C] my-8"
        >
          {/* Close Button */}
          <button
            id="btn-close-sound-modal"
            onClick={() => {
              sound.playSubtleClick();
              onClose();
            }}
            className="absolute top-5 right-5 p-2 text-[#777777] hover:text-[#1C1C1C] hover:bg-[#F2F1EE] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Modal Header */}
          <div className="mb-6">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#F8F7F4] border border-[#EAE8E4] text-[#B9975B] text-[10px] font-mono tracking-[0.25em] uppercase mb-2.5 font-bold">
              <Sparkles className="w-3.5 h-3.5 text-[#B9975B]" />
              Acoustic Synthesizer Architecture
            </div>
            <h2 className="text-2xl sm:text-3xl font-serif text-[#1C1C1C] tracking-normal font-light">
              Sensory Web Audio Experience
            </h2>
            <p className="text-xs text-[#555555] mt-1.5 max-w-lg font-sans leading-relaxed">
              Every button, drawer, and purchase touchpoint in the atelier is mapped to real-time harmonic Web Audio oscillators — delivering rich tactile feedback without external asset loading lag.
            </p>
          </div>

          {/* Interactive Sound Test Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6">
            {testSounds.map(item => {
              const isActive = activeTest === item.id;
              return (
                <motion.div
                  key={item.id}
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => handleTest(item)}
                  className={`
                    relative p-3.5 border transition-all duration-200 cursor-pointer select-none text-left
                    ${
                      isActive
                        ? 'bg-[#F8F7F4] border-[#B9975B] shadow-sm'
                        : 'bg-[#F8F7F4] border-[#EAE8E4] hover:border-[#B9975B]/60 hover:bg-[#FFFFFF]'
                    }
                  `}
                >
                  <div className="flex items-start justify-between gap-2 mb-1.5">
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-[#FFFFFF] border border-[#EAE8E4]">
                        {item.icon}
                      </div>
                      <div>
                        <h4 className="text-xs font-serif font-semibold text-[#1C1C1C] tracking-wide">{item.title}</h4>
                        <span className="text-[9px] text-[#B9975B] tracking-wider uppercase font-mono block">
                          {item.category}
                        </span>
                      </div>
                    </div>
                    <div className="p-1 bg-[#FFFFFF] border border-[#EAE8E4] text-[#1C1C1C]">
                      <Play className="w-2.5 h-2.5 fill-current" />
                    </div>
                  </div>
                  <p className="text-[11px] text-[#555555] leading-relaxed font-sans">{item.description}</p>
                  <div className="mt-2 pt-2 border-t border-[#EAE8E4] flex items-center justify-between text-[9px] font-mono text-[#777777]">
                    <span>Harmonic: {item.freq}</span>
                    <span className="text-[#B9975B] font-bold">Trigger Sound</span>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Technical Guarantee Badge */}
          <div className="flex items-center gap-3 p-3.5 bg-[#F8F7F4] border border-[#EAE8E4] text-xs text-[#555555] mb-6 font-sans">
            <ShieldCheck className="w-5 h-5 text-[#B9975B] shrink-0" />
            <p className="text-[11px] leading-relaxed">
              Synthesized natively via standard <strong>AudioContext Oscillators & Biquad Filters</strong>. Safe for battery life, instantly responsive, and automatically muted if your device volume is low.
            </p>
          </div>

          {/* Footer Action */}
          <div className="flex justify-end gap-3">
            <AnimatedButton
              id="btn-dismiss-sound-modal"
              variant="primary-solid-gold"
              size="md"
              soundType="click"
              onClick={onClose}
              className="w-full sm:w-auto px-8 text-[10px] tracking-[0.2em]"
            >
              Return to Collection
            </AnimatedButton>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
