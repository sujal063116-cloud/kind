import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, ShoppingBag, Trash2, Plus, Minus, ShieldCheck, Sparkles, Check, ArrowRight, Truck, Gift } from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem } from '../types';
import { AnimatedButton } from './AnimatedButton';
import { sound } from '../utils/audio';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, quantity: number) => void;
  onRemoveItem: (index: number) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [checkoutStep, setCheckoutStep] = useState<'bag' | 'shipping' | 'payment' | 'confirmed'>('bag');
  const [selectedSamples, setSelectedSamples] = useState<string[]>(['sample-neroli', 'sample-santal']);
  const [shippingDetails, setShippingDetails] = useState({
    name: 'Eleanor Vance',
    email: 'eleanor.vance@residence.com',
    address: '740 Park Avenue, Penthouse B',
    city: 'New York, NY 10021',
  });
  const [orderNumber, setOrderNumber] = useState('');

  if (!isOpen) return null;

  const sampleOptions = [
    { id: 'sample-neroli', name: 'Neroli & Calabrian Bergamot (2ml)' },
    { id: 'sample-santal', name: 'Smoked Santal & Orris Root (2ml)' },
    { id: 'sample-fig', name: 'Botanical Fig & Cyclamen (2ml)' },
    { id: 'sample-cedar', name: 'Atlas Cedar & Silver Fir (2ml)' },
  ];

  const subtotal = items.reduce((sum, item) => {
    const unitPrice = item.isRefillPouch ? item.product.refillPrice : item.product.price;
    return sum + unitPrice * item.quantity;
  }, 0);

  const freeGiftThreshold = 120;
  const progressPercent = Math.min(100, (subtotal / freeGiftThreshold) * 100);
  const remainingForGift = Math.max(0, freeGiftThreshold - subtotal);

  const toggleSample = (id: string) => {
    sound.playSubtleClick();
    if (selectedSamples.includes(id)) {
      if (selectedSamples.length > 1) {
        setSelectedSamples(selectedSamples.filter(s => s !== id));
      }
    } else {
      if (selectedSamples.length < 2) {
        setSelectedSamples([...selectedSamples, id]);
      } else {
        setSelectedSamples([selectedSamples[1], id]);
      }
    }
  };

  const handleProceedToShipping = () => {
    sound.playSubtleClick();
    setCheckoutStep('shipping');
  };

  const handleProceedToPayment = () => {
    sound.playSubtleClick();
    setCheckoutStep('payment');
  };

  const handleCompleteOrder = () => {
    const generatedOrder = `ÉLAN-${Math.floor(100000 + Math.random() * 900000)}`;
    setOrderNumber(generatedOrder);
    setCheckoutStep('confirmed');
    sound.playSuccessCelebration();

    // Trigger golden luxury confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#d4af37', '#f3e5ab', '#ffffff', '#c5a059'],
      });
    } catch {
      // Confetti fallback
    }
  };

  const handleResetCheckout = () => {
    onClearCart();
    setCheckoutStep('bag');
    onClose();
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 overflow-hidden">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {
            sound.playSubtleClick();
            onClose();
          }}
          className="absolute inset-0 bg-black/40 backdrop-blur-sm transition-opacity"
        />

        <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 28, stiffness: 300 }}
            className="w-screen max-w-md bg-[#FFFFFF] border-l border-[#EAE8E4] shadow-[0_0_60px_rgba(0,0,0,0.15)] flex flex-col justify-between overflow-hidden text-[#1C1C1C]"
          >
            {/* Drawer Header */}
            <div className="p-5 border-b border-[#EAE8E4] flex items-center justify-between bg-[#F8F7F4]">
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-[#B9975B]" />
                <h3 className="font-serif text-base text-[#1C1C1C] font-normal tracking-wide">
                  {checkoutStep === 'confirmed' ? 'Order Confirmed' : 'Your Atelier Bag'}
                </h3>
                {items.length > 0 && checkoutStep !== 'confirmed' && (
                  <span className="text-[10px] font-mono px-2 py-0.5 bg-[#1C1C1C] text-white">
                    {items.reduce((s, i) => s + i.quantity, 0)} items
                  </span>
                )}
              </div>

              <button
                id="btn-close-cart-drawer"
                onClick={() => {
                  sound.playSubtleClick();
                  onClose();
                }}
                className="p-1.5 text-[#777777] hover:text-[#1C1C1C] hover:bg-[#EAE8E4] transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Gift Threshold Progress Bar */}
            {checkoutStep === 'bag' && items.length > 0 && (
              <div className="p-3.5 bg-[#F8F7F4] border-b border-[#EAE8E4] text-xs space-y-1.5">
                <div className="flex items-center justify-between text-[10px] font-mono">
                  <span className="text-[#1C1C1C] flex items-center gap-1">
                    <Gift className="w-3.5 h-3.5 text-[#B9975B]" />
                    {remainingForGift === 0
                      ? 'Complimentary Grasse Mist Unlocked!'
                      : `Add $${remainingForGift} more for Free Grasse Mist`}
                  </span>
                  <span className="text-[#B9975B] font-bold">{Math.round(progressPercent)}%</span>
                </div>
                <div className="w-full bg-[#EAE8E4] h-1 overflow-hidden">
                  <motion.div
                    className="h-full bg-[#B9975B]"
                    initial={{ width: 0 }}
                    animate={{ width: `${progressPercent}%` }}
                    transition={{ duration: 0.5 }}
                  />
                </div>
              </div>
            )}

            {/* Drawer Body */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              
              {/* STEP: Bag Items View */}
              {checkoutStep === 'bag' && (
                <>
                  {items.length === 0 ? (
                    <div className="py-16 text-center space-y-4">
                      <div className="w-14 h-14 bg-[#F8F7F4] border border-[#EAE8E4] flex items-center justify-center mx-auto text-[#999999]">
                        <ShoppingBag className="w-6 h-6" />
                      </div>
                      <p className="font-serif text-lg text-[#1C1C1C]">Your bag is currently empty.</p>
                      <p className="text-xs text-[#555555] max-w-xs mx-auto font-sans">
                        Explore our botanical all-surface elixirs, dish washes, and linen elixirs to begin your ritual.
                      </p>
                      <AnimatedButton
                        id="btn-empty-bag-return"
                        variant="primary-solid-gold"
                        size="md"
                        soundType="click"
                        onClick={onClose}
                        className="mt-2 text-[10px] tracking-[0.2em]"
                      >
                        Explore Atelier
                      </AnimatedButton>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {items.map((item, index) => {
                        const unitPrice = item.isRefillPouch ? item.product.refillPrice : item.product.price;
                        return (
                          <motion.div
                            key={`${item.product.id}-${index}`}
                            layout
                            className="p-3 bg-[#F8F7F4] border border-[#EAE8E4] flex gap-3 relative"
                          >
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              className="w-16 h-16 object-contain bg-[#FFFFFF] p-1 border border-[#EAE8E4]"
                            />
                            <div className="flex-1 min-w-0 space-y-1">
                              <div className="flex justify-between items-start">
                                <h4 className="text-xs font-serif font-semibold text-[#1C1C1C] truncate">
                                  {item.product.name}
                                </h4>
                                <button
                                  id={`btn-remove-cart-${index}`}
                                  onClick={() => {
                                    sound.playSubtleClick();
                                    onRemoveItem(index);
                                  }}
                                  className="text-[#999999] hover:text-red-500 p-0.5 cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </div>

                              <span className="text-[9px] font-mono uppercase tracking-wider text-[#B9975B] block">
                                {item.isRefillPouch ? 'Eco-Refill Pouch' : 'Heirloom Amber Flacon'}
                              </span>

                              {item.engraving && (
                                <span className="text-[9px] font-mono text-[#555555] block bg-[#FFFFFF] border border-[#EAE8E4] px-1.5 py-0.5">
                                  Monogram: &quot;{item.engraving}&quot;
                                </span>
                              )}

                              <div className="pt-1 flex items-center justify-between">
                                {/* Quantity stepper */}
                                <div className="flex items-center bg-[#FFFFFF] border border-[#EAE8E4] p-0.5">
                                  <button
                                    id={`btn-cart-minus-${index}`}
                                    onClick={() => onUpdateQuantity(index, item.quantity - 1)}
                                    className="p-1 hover:bg-[#F2F1EE] text-[#555555] hover:text-[#1C1C1C] cursor-pointer"
                                  >
                                    <Minus className="w-3 h-3" />
                                  </button>
                                  <span className="w-6 text-center text-xs font-mono font-bold text-[#1C1C1C]">
                                    {item.quantity}
                                  </span>
                                  <button
                                    id={`btn-cart-plus-${index}`}
                                    onClick={() => onUpdateQuantity(index, item.quantity + 1)}
                                    className="p-1 hover:bg-[#F2F1EE] text-[#555555] hover:text-[#1C1C1C] cursor-pointer"
                                  >
                                    <Plus className="w-3 h-3" />
                                  </button>
                                </div>

                                <span className="text-xs font-serif font-semibold text-[#1C1C1C]">
                                  ${unitPrice * item.quantity}
                                </span>
                              </div>
                            </div>
                          </motion.div>
                        );
                      })}

                      {/* Complimentary Grasse Samples Selector */}
                      <div className="p-3.5 bg-[#F8F7F4] border border-[#EAE8E4] space-y-2 mt-4">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-serif text-[#1C1C1C] flex items-center gap-1.5 font-medium">
                            <Sparkles className="w-3.5 h-3.5 text-[#B9975B]" />
                            Complimentary Discovery Vials (Select 2)
                          </span>
                          <span className="text-[10px] font-mono text-[#777777]">
                            {selectedSamples.length}/2
                          </span>
                        </div>

                        <div className="space-y-1.5 text-xs">
                          {sampleOptions.map(s => {
                            const isSelected = selectedSamples.includes(s.id);
                            return (
                              <div
                                key={s.id}
                                id={`btn-sample-toggle-${s.id}`}
                                onClick={() => toggleSample(s.id)}
                                className={`flex items-center justify-between p-2 border cursor-pointer transition-all ${
                                  isSelected
                                    ? 'bg-[#FFFFFF] border-[#B9975B] text-[#1C1C1C] shadow-sm'
                                    : 'bg-[#FFFFFF] border-[#EAE8E4] text-[#777777] hover:border-[#B9975B]/60'
                                }`}
                              >
                                <span className="text-[11px] font-serif">{s.name}</span>
                                {isSelected && <Check className="w-3.5 h-3.5 text-[#B9975B]" />}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}

              {/* STEP: Shipping View */}
              {checkoutStep === 'shipping' && (
                <div className="space-y-4 text-xs">
                  <div className="p-3 bg-[#F8F7F4] border border-[#EAE8E4] flex items-center gap-2 text-[#555555]">
                    <Truck className="w-4 h-4 text-[#B9975B]" />
                    <span>Complimentary Insured White-Glove Courier Delivery</span>
                  </div>

                  <div className="space-y-3">
                    <div>
                      <label className="block text-[#555555] mb-1 font-mono uppercase text-[9px] tracking-wider font-bold">
                        Recipient Name
                      </label>
                      <input
                        id="input-ship-name"
                        type="text"
                        value={shippingDetails.name}
                        onChange={e => setShippingDetails({ ...shippingDetails, name: e.target.value })}
                        className="w-full bg-[#F8F7F4] border border-[#EAE8E4] focus:border-[#B9975B] px-3 py-2 text-xs text-[#1C1C1C] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[#555555] mb-1 font-mono uppercase text-[9px] tracking-wider font-bold">
                        Atelier Member Email
                      </label>
                      <input
                        id="input-ship-email"
                        type="email"
                        value={shippingDetails.email}
                        onChange={e => setShippingDetails({ ...shippingDetails, email: e.target.value })}
                        className="w-full bg-[#F8F7F4] border border-[#EAE8E4] focus:border-[#B9975B] px-3 py-2 text-xs text-[#1C1C1C] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[#555555] mb-1 font-mono uppercase text-[9px] tracking-wider font-bold">
                        Residence Address & Suite
                      </label>
                      <input
                        id="input-ship-address"
                        type="text"
                        value={shippingDetails.address}
                        onChange={e => setShippingDetails({ ...shippingDetails, address: e.target.value })}
                        className="w-full bg-[#F8F7F4] border border-[#EAE8E4] focus:border-[#B9975B] px-3 py-2 text-xs text-[#1C1C1C] focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[#555555] mb-1 font-mono uppercase text-[9px] tracking-wider font-bold">
                        City, State & Postal Code
                      </label>
                      <input
                        id="input-ship-city"
                        type="text"
                        value={shippingDetails.city}
                        onChange={e => setShippingDetails({ ...shippingDetails, city: e.target.value })}
                        className="w-full bg-[#F8F7F4] border border-[#EAE8E4] focus:border-[#B9975B] px-3 py-2 text-xs text-[#1C1C1C] focus:outline-none"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* STEP: Payment View */}
              {checkoutStep === 'payment' && (
                <div className="space-y-4 text-xs">
                  <div className="p-3.5 bg-[#F8F7F4] border border-[#EAE8E4] space-y-3">
                    <span className="text-[9px] uppercase font-mono tracking-[0.2em] text-[#B9975B] block font-bold">
                      Express Atelier Settlement
                    </span>

                    <div className="p-3 bg-[#FFFFFF] border border-[#B9975B] flex items-center justify-between cursor-pointer">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 bg-[#B9975B]" />
                        <span className="font-medium text-[#1C1C1C]">Apple Pay / Touch ID</span>
                      </div>
                      <span className="text-[10px] font-mono text-[#B9975B]">Instant Verification</span>
                    </div>

                    <div className="p-3 bg-[#FFFFFF] border border-[#EAE8E4] flex items-center justify-between opacity-70">
                      <div className="flex items-center gap-2">
                        <div className="w-2.5 h-2.5 border border-[#999999]" />
                        <span className="text-[#777777]">Concierge Luxury Card (Amex Centurion / Black)</span>
                      </div>
                    </div>
                  </div>

                  <div className="p-3 bg-[#F8F7F4] border border-[#EAE8E4] text-[10px] font-mono text-[#555555] space-y-1">
                    <p className="text-[#1C1C1C] font-semibold uppercase">Deliver To:</p>
                    <p>{shippingDetails.name}</p>
                    <p>{shippingDetails.address}, {shippingDetails.city}</p>
                  </div>
                </div>
              )}

              {/* STEP: Confirmed Order View */}
              {checkoutStep === 'confirmed' && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="py-6 text-center space-y-4"
                >
                  <div className="w-14 h-14 bg-[#F8F7F4] border border-[#B9975B] flex items-center justify-center mx-auto text-[#B9975B]">
                    <Check className="w-7 h-7 stroke-[2.5]" />
                  </div>

                  <div>
                    <span className="text-[9px] uppercase font-mono tracking-[0.3em] text-[#B9975B] block font-bold">
                      Order Confirmed
                    </span>
                    <h3 className="font-serif text-2xl text-[#1C1C1C] font-light mt-1">Merci Beaucoup</h3>
                    <p className="text-xs text-[#555555] mt-1 font-sans">
                      Order Reference: <strong className="font-mono text-[#1C1C1C]">{orderNumber}</strong>
                    </p>
                  </div>

                  <div className="p-4 bg-[#F8F7F4] border border-[#EAE8E4] text-left text-xs space-y-2 text-[#555555] font-sans">
                    <p>• Your bespoke amber flacons are being filled by hand in our atelier.</p>
                    <p>• Tracking dispatch details sent to <strong>{shippingDetails.email}</strong>.</p>
                    <p>• Complimentary Grasse fragrance vials are included in the presentation box.</p>
                  </div>

                  <AnimatedButton
                    id="btn-confirmed-finish"
                    variant="primary-solid-gold"
                    size="md"
                    soundType="click"
                    onClick={handleResetCheckout}
                    className="w-full text-[10px] tracking-[0.2em]"
                  >
                    Return to Atelier Catalogue
                  </AnimatedButton>
                </motion.div>
              )}
            </div>

            {/* Drawer Footer Actions */}
            {items.length > 0 && checkoutStep !== 'confirmed' && (
              <div className="p-5 border-t border-[#EAE8E4] bg-[#F8F7F4] space-y-3">
                <div className="space-y-1.5 text-xs">
                  <div className="flex justify-between text-[#555555]">
                    <span>Subtotal</span>
                    <span className="font-mono text-[#1C1C1C]">${subtotal}</span>
                  </div>
                  <div className="flex justify-between text-[#555555]">
                    <span>Concierge Courier Delivery</span>
                    <span className="font-mono text-[#B9975B]">Complimentary</span>
                  </div>
                  <div className="flex justify-between text-sm font-serif text-[#1C1C1C] pt-2 border-t border-[#EAE8E4]">
                    <span>Estimated Total</span>
                    <span className="font-serif font-light text-base text-[#1C1C1C]">${subtotal}</span>
                  </div>
                </div>

                {checkoutStep === 'bag' && (
                  <AnimatedButton
                    id="btn-checkout-proceed-shipping"
                    variant="primary-solid-gold"
                    size="lg"
                    soundType="modal"
                    onClick={handleProceedToShipping}
                    icon={<ArrowRight className="w-3.5 h-3.5" />}
                    iconPosition="right"
                    className="w-full text-[10px] font-medium tracking-[0.25em]"
                  >
                    Proceed to Delivery Suite
                  </AnimatedButton>
                )}

                {checkoutStep === 'shipping' && (
                  <div className="flex gap-2">
                    <AnimatedButton
                      id="btn-shipping-back-to-bag"
                      variant="outline-minimal"
                      size="md"
                      soundType="click"
                      onClick={() => setCheckoutStep('bag')}
                      className="text-[10px] tracking-[0.2em]"
                    >
                      Back
                    </AnimatedButton>
                    <AnimatedButton
                      id="btn-shipping-proceed-payment"
                      variant="primary-solid-gold"
                      size="md"
                      soundType="modal"
                      onClick={handleProceedToPayment}
                      icon={<ArrowRight className="w-3.5 h-3.5" />}
                      iconPosition="right"
                      className="flex-1 text-[10px] font-medium tracking-[0.25em]"
                    >
                      Continue to Settlement
                    </AnimatedButton>
                  </div>
                )}

                {checkoutStep === 'payment' && (
                  <div className="flex gap-2">
                    <AnimatedButton
                      id="btn-payment-back-to-shipping"
                      variant="outline-minimal"
                      size="md"
                      soundType="click"
                      onClick={() => setCheckoutStep('shipping')}
                      className="text-[10px] tracking-[0.2em]"
                    >
                      Back
                    </AnimatedButton>
                    <AnimatedButton
                      id="btn-complete-settlement"
                      variant="primary-solid-gold"
                      size="md"
                      soundType="none"
                      onClick={handleCompleteOrder}
                      icon={<ShieldCheck className="w-3.5 h-3.5 text-white" />}
                      className="flex-1 text-[10px] font-medium tracking-[0.25em]"
                    >
                      Authorize & Complete (${subtotal})
                    </AnimatedButton>
                  </div>
                )}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </AnimatePresence>
  );
};
