import React, { useState, useEffect } from 'react';
import { Volume2, VolumeX, Sparkles, Sliders, Music } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { sound } from '../utils/audio';
import { AnimatedButton } from './AnimatedButton';

interface SensoryAudioHudProps {
  onOpenSoundStudio: () => void;
}

export const SensoryAudioHud: React.FC<SensoryAudioHudProps> = ({ onOpenSoundStudio }) => {
  const [isMuted, setIsMuted] = useState(sound.getIsMuted());
  const [volume, setVolume] = useState(sound.getVolume());
  const [isAmbientPlaying, setIsAmbientPlaying] = useState(sound.getIsAmbientPlaying());
  const [isOpenMenu, setIsOpenMenu] = useState(false);

  useEffect(() => {
    const unsub = sound.subscribe(state => {
      setIsMuted(state.isMuted);
      setVolume(state.volume);
      setIsAmbientPlaying(state.isAmbientPlaying);
    });
    return unsub;
  }, []);

  const handleToggleMute = () => {
    sound.toggleMute();
    sound.playMetallicToggle();
  };

  const handleToggleAmbient = () => {
    sound.toggleAmbientSound();
    sound.playSubtleClick();
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    sound.setVolume(val);
  };

  return (
    <div className="relative inline-flex items-center">
      <div className="flex items-center gap-1.5 bg-[#FFFFFF] border border-[#EAE8E4] rounded-none px-2.5 py-1 shadow-sm">
        {/* Live Audio Equalizer Visualizer Bars */}
        <div
          onClick={handleToggleMute}
          title={isMuted ? 'Unmute Atelier Acoustics' : 'Mute Atelier Acoustics'}
          className="flex items-center gap-[2.5px] h-4 px-1 cursor-pointer group"
        >
          {[0.6, 0.9, 0.4, 0.8, 0.5].map((heightScale, i) => (
            <motion.span
              key={i}
              className={`w-[2px] rounded-none transition-colors duration-300 ${
                isMuted
                  ? 'bg-neutral-300 h-1.5'
                  : isAmbientPlaying
                  ? 'bg-[#B9975B]'
                  : 'bg-[#B9975B]/70 group-hover:bg-[#B9975B]'
              }`}
              animate={
                !isMuted && isAmbientPlaying
                  ? {
                      height: [
                        `${4 * heightScale}px`,
                        `${16 * heightScale}px`,
                        `${6 * heightScale}px`,
                        `${14 * heightScale}px`,
                      ],
                    }
                  : { height: isMuted ? '4px' : `${8 * heightScale}px` }
              }
              transition={{
                repeat: Infinity,
                duration: 0.8 + i * 0.15,
                ease: 'easeInOut',
              }}
            />
          ))}
        </div>

        {/* Master Mute / Unmute Button */}
        <button
          id="btn-sound-mute-toggle"
          onClick={handleToggleMute}
          className="p-1 text-[#1C1C1C] hover:text-[#B9975B] transition-colors focus:outline-none"
          title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          aria-label={isMuted ? 'Unmute Audio' : 'Mute Audio'}
        >
          {isMuted ? <VolumeX className="w-3.5 h-3.5 text-neutral-400" /> : <Volume2 className="w-3.5 h-3.5" />}
        </button>

        {/* Ambient Soundscape Toggle */}
        <button
          id="btn-sound-ambient-toggle"
          onClick={handleToggleAmbient}
          className={`flex items-center gap-1 px-2 py-0.5 text-[10px] font-medium tracking-[0.2em] uppercase transition-all duration-300 ${
            isAmbientPlaying
              ? 'bg-[#B9975B] text-white'
              : 'text-[#555555] hover:text-[#1C1C1C] hover:bg-[#F2F1EE]'
          }`}
          title="Toggle 432Hz Generative Atelier Atmosphere"
        >
          <Music className={`w-2.5 h-2.5 ${isAmbientPlaying ? 'animate-spin text-white' : ''}`} />
          <span className="hidden sm:inline text-[9px]">
            {isAmbientPlaying ? 'Atmosphere ON' : 'Atmosphere'}
          </span>
        </button>

        {/* Settings / Sound Studio Trigger */}
        <button
          id="btn-sound-menu-toggle"
          onClick={() => setIsOpenMenu(!isOpenMenu)}
          className="p-1 text-[#555555] hover:text-[#B9975B] transition-colors"
          title="Audio Acoustics Settings"
          aria-label="Audio Acoustics Settings"
        >
          <Sliders className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Popover Settings Dropdown */}
      <AnimatePresence>
        {isOpenMenu && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 8, scale: 0.95 }}
            transition={{ duration: 0.2 }}
            className="absolute right-0 top-full mt-2 w-64 p-4 bg-[#FFFFFF] border border-[#EAE8E4] shadow-[0_20px_40px_rgba(0,0,0,0.08)] z-50 text-xs text-[#1C1C1C]"
          >
            <div className="flex items-center justify-between pb-2 mb-3 border-b border-[#EAE8E4]">
              <span className="font-serif text-sm tracking-wide text-[#1C1C1C] font-medium">
                Atelier Sound Design
              </span>
              <span className="px-1.5 py-0.5 text-[9px] uppercase tracking-widest bg-[#F2F1EE] text-[#B9975B] font-mono">
                Web Audio
              </span>
            </div>

            {/* Master Volume */}
            <div className="space-y-1.5 mb-3.5">
              <div className="flex justify-between text-[#555555] text-[11px]">
                <span>Acoustic Volume</span>
                <span className="font-mono text-[#B9975B]">{Math.round(volume * 100)}%</span>
              </div>
              <input
                id="input-sound-volume-slider"
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={volume}
                onChange={handleVolumeChange}
                className="w-full accent-[#B9975B] bg-[#EAE8E4] h-1.5 cursor-pointer"
              />
            </div>

            {/* Ambient Soundscape */}
            <div className="flex items-center justify-between py-2 border-t border-[#EAE8E4]">
              <div>
                <p className="text-[#1C1C1C] font-medium text-[11px]">Generative 432Hz Ambiance</p>
                <p className="text-[10px] text-[#777777]">Harmonic sine drone</p>
              </div>
              <button
                id="btn-sound-ambient-popover-toggle"
                onClick={handleToggleAmbient}
                className={`w-9 h-5 transition-colors relative ${
                  isAmbientPlaying ? 'bg-[#B9975B]' : 'bg-[#EAE8E4]'
                }`}
              >
                <motion.div
                  animate={{ x: isAmbientPlaying ? 18 : 2 }}
                  className="w-3.5 h-3.5 bg-white absolute top-[3px]"
                />
              </button>
            </div>

            {/* Button to Open Sound Studio Test Board */}
            <div className="pt-3 mt-1 border-t border-[#EAE8E4]">
              <AnimatedButton
                id="btn-open-sound-studio-modal"
                variant="secondary-glass"
                size="sm"
                soundType="modal"
                onClick={() => {
                  setIsOpenMenu(false);
                  onOpenSoundStudio();
                }}
                className="w-full text-[10px] justify-center py-2 border-[#D8D4CC]"
                icon={<Sparkles className="w-3 h-3 text-[#B9975B]" />}
              >
                Launch Sound Lab & Test Pads
              </AnimatedButton>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
