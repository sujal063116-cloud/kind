export interface Product {
  id: string;
  name: string;
  frenchTitle: string;
  subtitle: string;
  category: 'culinary' | 'surface' | 'laundry' | 'atmosphere' | 'utensils' | 'sets';
  price: number;
  refillPrice: number;
  volume: string;
  rating: number;
  reviewsCount: number;
  fragranceFamily: 'Citrus & Neroli' | 'Smoked Santal' | 'Botanical Fig' | 'Wild Cedar & Vetiver' | 'Unscented Pure';
  notes: {
    top: string[];
    heart: string[];
    base: string[];
  };
  description: string;
  formulaHighlights: string[];
  surfaceSuitability: string[];
  ecoMetrics: {
    plasticSavedGrams: number;
    biodegradablePercent: number;
    refillsCount: number;
  };
  image: string;
  bottleVariant: 'amber-glass' | 'frosted-obsidian' | 'champagne-brass' | 'refill-aluminum';
  badge?: string;
  inStock: boolean;
  featured?: boolean;
}

export interface CartItem {
  product: Product;
  quantity: number;
  isRefillPouch: boolean;
  engraving?: string;
}

export interface SoundSettings {
  isMuted: boolean;
  volume: number; // 0.0 to 1.0
  ambientEnabled: boolean;
  hapticsAudioEnabled: boolean;
}

export interface ScentNoteVisual {
  name: string;
  category: 'top' | 'heart' | 'base';
  aromaDescription: string;
  color: string;
}

export interface ConciergeRecommendation {
  primaryProduct: Product;
  companionProduct: Product;
  recommendedRefill: Product;
  matchScore: number;
  diagnosticNotes: string;
}
