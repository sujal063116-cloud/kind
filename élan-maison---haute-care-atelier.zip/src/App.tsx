import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Sparkles, SlidersHorizontal, ArrowUpDown, Volume2, ShieldCheck, Droplets, Check } from 'lucide-react';
import { LUXURY_PRODUCTS } from './data/products';
import { Product, CartItem } from './types';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ProductCard } from './components/ProductCard';
import { FragranceShowcase } from './components/FragranceShowcase';
import { RefillAtelier } from './components/RefillAtelier';
import { AtelierManifesto } from './components/AtelierManifesto';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ConciergeDiagnostic } from './components/ConciergeDiagnostic';
import { CartDrawer } from './components/CartDrawer';
import { SoundDesignModal } from './components/SoundDesignModal';
import { AnimatedButton } from './components/AnimatedButton';
import { Footer } from './components/Footer';
import { sound } from './utils/audio';

export default function App() {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [activeScent, setActiveScent] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [ecoFilterOnly, setEcoFilterOnly] = useState<boolean>(false);

  // Modals & Drawers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isConciergeOpen, setIsConciergeOpen] = useState<boolean>(false);
  const [isSoundStudioOpen, setIsSoundStudioOpen] = useState<boolean>(false);
  const [hasInteracted, setHasInteracted] = useState<boolean>(false);

  // Cart State with LocalStorage Persistence
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('elan_maison_cart');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // ignore
    }
    // Default initial luxury item in bag for delight
    return [
      {
        product: LUXURY_PRODUCTS[0],
        quantity: 1,
        isRefillPouch: false,
        engraving: 'VILLA ÉLAN',
      },
    ];
  });

  useEffect(() => {
    try {
      localStorage.setItem('elan_maison_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  // Initial user interaction detector for Web Audio unlock
  const handleUserFirstInteraction = () => {
    if (!hasInteracted) {
      setHasInteracted(true);
    }
  };

  // Cart handlers
  const handleAddToCart = (
    product: Product,
    isRefill: boolean = false,
    engraving?: string,
    quantity: number = 1
  ) => {
    setCart(prev => {
      const existingIdx = prev.findIndex(
        item =>
          item.product.id === product.id &&
          item.isRefillPouch === isRefill &&
          item.engraving === engraving
      );
      if (existingIdx > -1) {
        const updated = [...prev];
        updated[existingIdx].quantity += quantity;
        return updated;
      }
      return [...prev, { product, quantity, isRefillPouch: isRefill, engraving }];
    });
  };

  const handleAddBundleToCart = (products: Product[]) => {
    products.forEach(p => handleAddToCart(p, false));
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (index: number, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(index);
      return;
    }
    setCart(prev => {
      const updated = [...prev];
      updated[index].quantity = quantity;
      return updated;
    });
  };

  const handleRemoveItem = (index: number) => {
    setCart(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Filtering & Sorting
  const filteredProducts = useMemo(() => {
    return LUXURY_PRODUCTS.filter(p => {
      // Category filter
      if (activeCategory !== 'all' && p.category !== activeCategory) {
        return false;
      }
      // Scent filter
      if (activeScent !== 'all' && p.fragranceFamily !== activeScent) {
        return false;
      }
      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = p.name.toLowerCase().includes(q) || p.frenchTitle.toLowerCase().includes(q);
        const matchesScent = p.fragranceFamily.toLowerCase().includes(q);
        const matchesNotes = p.notes.top.some(n => n.toLowerCase().includes(q)) || p.notes.heart.some(n => n.toLowerCase().includes(q));
        const matchesSurface = p.surfaceSuitability.some(s => s.toLowerCase().includes(q));
        if (!matchesName && !matchesScent && !matchesNotes && !matchesSurface) {
          return false;
        }
      }
      // Eco filter
      if (ecoFilterOnly && p.ecoMetrics.plasticSavedGrams < 150) {
        return false;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });
  }, [activeCategory, activeScent, searchQuery, sortBy, ecoFilterOnly]);

  const totalCartCount = cart.reduce((sum, i) => sum + i.quantity, 0);

  return (
    <div
      onClick={handleUserFirstInteraction}
      className="min-h-screen bg-[#F8F7F4] text-[#1C1C1C] flex flex-col selection:bg-[#B9975B]/20 selection:text-[#1C1C1C]"
    >
      {/* Navigation Bar */}
      <Navbar
        activeCategory={activeCategory}
        onSelectCategory={cat => {
          sound.playSubtleClick();
          setActiveCategory(cat);
        }}
        cartCount={totalCartCount}
        onOpenCart={() => {
          sound.playModalOpen();
          setIsCartOpen(true);
        }}
        onOpenConcierge={() => {
          sound.playDroplet();
          setIsConciergeOpen(true);
        }}
        onOpenSoundStudio={() => {
          sound.playModalOpen();
          setIsSoundStudioOpen(true);
        }}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        products={LUXURY_PRODUCTS}
        onSelectProduct={p => setSelectedProduct(p)}
      />

      {/* Hero Editorial Stage */}
      <HeroSection
        signatureProduct={LUXURY_PRODUCTS[0]}
        onAddToCart={handleAddToCart}
        onOpenProductDetail={p => setSelectedProduct(p)}
        onOpenConcierge={() => setIsConciergeOpen(true)}
      />

      {/* Fragrance Scent Mood Showcase Filter Strip */}
      <FragranceShowcase
        activeScent={activeScent}
        onSelectScent={setActiveScent}
      />

      {/* Main Product Catalog Section */}
      <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-20 w-full">
        
        {/* Catalog Header and Filter Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-8 mb-8 border-b border-[#EAE8E4]">
          <div>
            <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-[#B9975B] block font-bold">
              Haute Botanical Formulations
            </span>
            <h2 className="text-2xl sm:text-3xl font-serif text-[#1C1C1C] mt-1 font-light">
              {activeCategory === 'all'
                ? 'The Complete Atelier Catalogue'
                : activeCategory.toUpperCase()}
            </h2>
            <p className="text-xs text-[#555555] mt-1 font-sans">
              Showing {filteredProducts.length} certified botanical solution(s)
            </p>
          </div>

          {/* Filter / Sort Strip */}
          <div className="flex flex-wrap items-center gap-3 text-xs">
            {/* Eco Filter Toggle Button */}
            <button
              id="btn-eco-filter-toggle"
              onClick={() => {
                sound.playSubtleClick();
                setEcoFilterOnly(!ecoFilterOnly);
              }}
              className={`flex items-center gap-1.5 px-3 py-2 border transition-all cursor-pointer text-xs ${
                ecoFilterOnly
                  ? 'bg-[#1C1C1C] border-[#1C1C1C] text-white'
                  : 'bg-[#FFFFFF] border-[#EAE8E4] text-[#555555] hover:text-[#1C1C1C] hover:border-[#1C1C1C]'
              }`}
            >
              <Droplets className="w-3.5 h-3.5 text-[#B9975B]" />
              <span>High Eco-Impact Only</span>
            </button>

            {/* Sort Selector */}
            <div className="flex items-center gap-1.5 bg-[#FFFFFF] border border-[#EAE8E4] px-3 py-1.5 text-[#555555]">
              <ArrowUpDown className="w-3.5 h-3.5 text-[#B9975B]" />
              <select
                id="select-sort-products"
                value={sortBy}
                onChange={e => {
                  sound.playSubtleClick();
                  setSortBy(e.target.value as typeof sortBy);
                }}
                aria-label="Sort formulations by"
                className="bg-transparent text-xs text-[#1C1C1C] focus:outline-none cursor-pointer pr-2"
              >
                <option value="featured" className="bg-[#FFFFFF] text-[#1C1C1C]">
                  Curated Featured
                </option>
                <option value="rating" className="bg-[#FFFFFF] text-[#1C1C1C]">
                  Highest Rated
                </option>
                <option value="price-asc" className="bg-[#FFFFFF] text-[#1C1C1C]">
                  Price: Gentle to Rare
                </option>
                <option value="price-desc" className="bg-[#FFFFFF] text-[#1C1C1C]">
                  Price: Rare to Gentle
                </option>
              </select>
            </div>

            {/* Reset Filter Button if applied */}
            {(activeCategory !== 'all' || activeScent !== 'all' || searchQuery || ecoFilterOnly) && (
              <AnimatedButton
                id="btn-reset-catalog-filters"
                variant="outline-minimal"
                size="sm"
                soundType="click"
                onClick={() => {
                  setActiveCategory('all');
                  setActiveScent('all');
                  setSearchQuery('');
                  setEcoFilterOnly(false);
                }}
                className="text-[10px] tracking-[0.2em]"
              >
                Clear Filters
              </AnimatedButton>
            )}
          </div>
        </div>

        {/* Product Cards Grid */}
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center space-y-4 max-w-md mx-auto">
            <p className="font-serif text-xl text-[#1C1C1C]">No formulations found.</p>
            <p className="text-xs text-[#555555] font-sans">
              Try clearing search terms or selecting &apos;All Formulations&apos; to view our full collection.
            </p>
            <AnimatedButton
              id="btn-reset-filters-empty"
              variant="primary-solid-gold"
              size="md"
              soundType="click"
              onClick={() => {
                setActiveCategory('all');
                setActiveScent('all');
                setSearchQuery('');
                setEcoFilterOnly(false);
              }}
              className="text-[10px] tracking-[0.2em]"
            >
              Reset All Filters
            </AnimatedButton>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map(product => (
              <ProductCard
                key={product.id}
                product={product}
                onSelectProduct={p => setSelectedProduct(p)}
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        )}
      </main>

      {/* The Infinite Refill Architecture & Subscription Section */}
      <RefillAtelier
        products={LUXURY_PRODUCTS}
        onAddToCart={handleAddToCart}
      />

      {/* Atelier Philosophy & Brand Pillars */}
      <AtelierManifesto
        onOpenConcierge={() => setIsConciergeOpen(true)}
        onOpenSoundStudio={() => setIsSoundStudioOpen(true)}
      />

      {/* Footer */}
      <Footer
        onOpenSoundStudio={() => setIsSoundStudioOpen(true)}
        onOpenConcierge={() => setIsConciergeOpen(true)}
      />

      {/* Modals and Drawers */}
      
      {/* Product Detail & Formulation Specs Modal */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={Boolean(selectedProduct)}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Botanical Scent & Surface Concierge Diagnostic Modal */}
      <ConciergeDiagnostic
        isOpen={isConciergeOpen}
        onClose={() => setIsConciergeOpen(false)}
        products={LUXURY_PRODUCTS}
        onAddBundleToCart={handleAddBundleToCart}
      />

      {/* Slide-out Cart Drawer with Multi-step Checkout Simulation */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* Sensory Web Audio Studio Modal */}
      <SoundDesignModal
        isOpen={isSoundStudioOpen}
        onClose={() => setIsSoundStudioOpen(false)}
      />
    </div>
  );
}
